package Driver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.conn.HttpHostConnectException;
import org.openqa.selenium.WebDriver;
import org.testng.TestNG;
import org.testng.TestNGException;
import WDUtilities.CommonUtil;
import WDUtilities.DBInterface;
import WDUtilities.DataDriverJXL;
import WDUtilities.Email;
import WDUtilities.ZipUtils;

import WDFrameworkComponents.GenericComponentImplementation;

public class TestDriver extends GenericComponentImplementation 
{
	public static WebDriver driver;
	public static String baseUrl="";
	public static String ServerURL="";
	public static String Username_DB="";
	public static String Password_DB=""; 
	public static String Username_UI="";
	public static String Password_UI=""; 
	public static int UI_EncounterLimit=0; 
	public static String BrowserName="";
	public static String SHEETNAME="";
	public static boolean acceptNextAlert = true;
	public static StringBuffer verificationErrors = new StringBuffer();
	public static DBInterface SQL;
	public static String EpiLogoName="Epi.png";
	public static void main(String[] args)

	{	 
		Test = new GenericComponentImplementation();	
		Test.setOutputDirectory(".//TestReports");
		Test.startUp();		
		ElementTimeout=Integer.parseInt(DataDriverJXL.getTestConfig("ELEMENT_TIMEOUT"));
		SHEETNAME=DataDriverJXL.getTestConfig("TestData_SheetName");
		ElementTimeout=Integer.parseInt(DataDriverJXL.getTestConfig("TIMEOUT")); 		
		try
		{			
			DBInterface Db=new DBInterface();
			/*Db.connectDBServer("jdbc:jtds:sqlserver://epidevsql.cd6nk8avjbps.us-east-1.rds.amazonaws.com/EpiconnectV3", "master", "EpicDb123");
			Db.connectDBServer("jdbc:jtds:sqlserver://10.3.1.138/SFDC", "ESPL1464", "Episource123");
			*///int DbCount_Sta=Db.getTotalNoOfQuery_DB("SELECT * From EPIP_TraverseResult where ID in ('472','473','474')");
			//statement = conn.prepareCall("{call "+Spname+"}");

			//'EBAC91AC-F4AE-4C2B-995C-FF362BBF2AF3','Admin','1d45315f-e842-4e70-a309-e8a2fb44e783'
			//Db.execSP("Get_DB_LastUpdationDate");
			//System.out.println(Db.execSPwithReturn("Get_DB_LastUpdationDate"));
			TestNG testng = new TestNG();
			List<String> suites = new ArrayList<String>();
			suites.add("./config/Testng.xml");
			System.out.println(suites);
			testng.setOutputDirectory(outputDirectory);
			testng.setTestSuites(suites);		
			testng.run(); 
		}
		//Test.setLog("ERROR",s.toString());
		catch (TestNGException e) 
		{
			e.printStackTrace();
			System.out.println(""+e.toString());
			setLog("ERROR",e.toString());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(""+e.toString());
			setLog("ERROR",e.toString());
		}
		// TODO: handle exception
		finally 	
		{

			if(DataDriverJXL.getTestConfig("EMAIL").equals("Yes"))
			{ 
				CommonUtil.removeSpecificFileTypesInFolder(outputDirectory);
				ZipUtils appZip = new ZipUtils();
				appZip.generateFileList(new File(outputDirectory));
				appZip.zipIt(GenericComponentImplementation.ResultFolderName+""); 				
				Email.SendEmail(projectAbsolutepath+"\\"+GenericComponentImplementation.ResultFolderName,DataDriverJXL.getTestConfig("Recipients"));
			}

			// WindowsUtils.killByName("IEDriverServer.exe");
			// Or using JavaRunTime
			try {
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			/*   try {
					//	closeBrowser();
					} catch (HttpHostConnectException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}*/
		}

	}

}