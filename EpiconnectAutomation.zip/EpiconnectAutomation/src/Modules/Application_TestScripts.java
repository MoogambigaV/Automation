package Modules; 
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import ModuleReusabelFunctions.ApplicationReusableFunctions;
import WDPOM.LoginPage;
public class Application_TestScripts  extends  ApplicationReusableFunctions
{

	LoginPage LoginPage=new LoginPage(); 

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception 
	{		
		getDriver().manage().timeouts().implicitlyWait(ElementTimeout, TimeUnit.SECONDS);	
		Test.getURL(baseUrl);	
	}
	@BeforeTest
	public void beforemethod()
	{

	}
	@BeforeMethod
	public void methodName(Method method)
	{
		currentMethodName=method.getName();	 
	}
	@Test(description="Add user-EDPS")
	public void TestCase001_AddUser()
	{

	}

	@AfterTest
	public  void testEnd()
	{	 

	}
	@AfterClass
	public  void testClass()
	{	 
		System.out.println("I am in classs");
	}
}
