package Modules; 
import org.testng.annotations.BeforeMethod;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.management.Query;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.DriverSessions;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import ModuleReusabelFunctions.ApplicationReusableFunctions;
import WDFrameworkComponents.GenericComponentImplementation;
import WDPOM.CodingProjectSummary;
import WDPOM.CodingSpecialProjects;
import WDPOM.ChartsDelivered;
import WDPOM.CodingAttestation;
import WDPOM.CreateYourGoogleAccount;
import WDPOM.DashboardAllProjects;
import WDPOM.DashboardsByProject;
import WDPOM.HRACAR;
import WDPOM.HRACaseManagement;
import WDPOM.HRAMemberSearch;
import WDPOM.HRAMemberStatus;
import WDPOM.HRAScheduledCompleted;
import WDPOM.HRAStatusDetail;
import WDPOM.HomePage;
import WDPOM.LoginPage;
import WDPOM.Logout;
import WDPOM.OptRetrievalDataExtract;
import WDPOM.OptumDataExtract;
import WDPOM.PNPDataExtract;
import WDPOM.PNPManagement;
import WDPOM.ProviderStatus;
import WDPOM.QueryBuilder;
import WDPOM.RetProjectSummary;
import WDPOM.RetrievedToDate;
import WDPOM.SFLoginPage;
import WDPOM.ScheduledInflow;
import WDPOM.Search;
import WDPOM.ChartImageFinder;
import WDUtilities.CommonUtil;
import WDUtilities.DBInterface;
import WDUtilities.DataDriverJXL;
import bsh.Console;
import jxl.read.biff.BiffException;
import jxl.write.DateTime;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;



@SuppressWarnings("unused")
public class Sanity_TestScripts extends ApplicationReusableFunctions
{	 	
	private static final DBInterface Db = null;
	public static Connection conn = null;
	public static CallableStatement statement = null;
	LoginPage LoginPage=new LoginPage(); 
	//SFLoginPage SFLP=new SFLoginPage();
	//@BeforeMethod
	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception 
	{
		GenericComponentImplementation.testFailure=false;
		setDriver(Test.openBrowser(DataDriverJXL.getTestConfig("Browser"),DataDriverJXL.getTestConfig("File_Downloads_Path")));
		maximizeBrowser();	 
		getURL(DataDriverJXL.getTestConfig("BASE URL"));
		LoginPage.Login(DataDriverJXL.getTestConfig("QA_Username_UI"), DataDriverJXL.getTestConfig("QA_Password_UI"));
		/*DBInterface Db=new DBInterface();
		Db.connectDBServer("epidevsql.cd6nk8avjbps.us-east-1.rds.amazonaws.com", "master", "EpicDb123");
		Db.execSP("EXEC Get_DB_LastUpdationDate");*/

		//Db.dbConnect("//17", db_userid, db_password);

		/*getURL(DataDriverJXL.getTestConfig("Salesforce URL"));
        SFLoginPage.SFLogin(DataDriverJXL.getTestConfig("SF_Username_UI"), DataDriverJXL.getTestConfig("SF_Password_UI"));*/
	}

	/*@SuppressWarnings("unused")
	public class Sanity_Test extends ApplicationReusableFunctions
	{	 	

		SFLoginPage SFLP=new SFLoginPage(); 
		//@BeforeMethod
		@BeforeClass(alwaysRun = true)
		public void setUp() throws Exception 
		{
	LoginPage.Login(DataDriverJXL.getTestConfig("QA_Username_UI"), DataDriverJXL.getTestConfig("QA_Password_UI"));
	getURL(DataDriverJXL.getTestConfig("QA_URL"));
	SFLP.Login(DataDriverJXL.getTestConfig("SF_Username_UI"), DataDriverJXL.getTestConfig("SF_Password_UI"));
}*/
	@BeforeMethod	
	public void beforemethodName(Method method)
	{
		currentMethodName=method.getName(); 
	}	
	/*********************************************************
	 * Usage: Test Script Sanity 
	 * Method name:TestScript_001
	 * Description: To validate the login is successful
	 * created by :Moogambiga V
	 * Date:08/24/2017
	 ********************************************************/
	@SuppressWarnings("unused")
	@Test(description="Dashboards")
	public void TestScript_001_Sanity() 
	{
		//String Clients[]={"Applecare","BSCA","DaVita California","Evolent Health","Humana","NAMM CA","Optum","Optum SNF","Harvard Pilgrim","HCP CA","Horizon"};
		String Clients[]={"Applecare"};
		HomePage HP=new HomePage();
		for(String Client :Clients)
		{
			clickOn(HP.Drp_HomePage_clickBtn);	
			HP.selectClient(HP.Lst_Epiconnect_homepage_clients, Client);
			waitForAjaxToFinish();
			verifyElementText("Client Dropdown;xpath~//button[contains(text(),'"+Client+"')]", Client);
			waitTime(2);
		}

	/*	String Clients[]={"Applecare","BSCA","Evolent Health","Harvard Pilgrim","HCP CA","Horizon","Humana","NAMM CA","Optum","Optum SNF"};
	String Clients[]=	DataDriverJXL.getTestData("Clients").split(",");
		HomePage HP=new HomePage();
	for(String Client :Clients)
		{
clickOn(HP.Drp_HomePage_clickBtn);	
		HP.selectClient(HP.Lst_Epiconnect_homepage_clients, Client);
		waitForAjaxToFinish();
	 verifyElementText("Client Dropdown;xpath~//button[contains(text(),'"+Client+"')]", Client);
	waitTime(2);
		String Clients[]=	DataDriverJXL.getTestData("Clients").split(",");*/
		
	}

	@Test(description="SF Login Page")
	public void TestScript_0041_Sanity() 
	{
		SFLoginPage SFLP=new SFLoginPage();
		waitTime(2);
		clickOn(SFLP.Click_ReportsTab);
		clickOn(SFLP.Click_Epiconnect_RetrievalStatus);
		waitTime(5);
		getURL(DataDriverJXL.getTestConfig("Salesforce URL"));
		SFLoginPage.SFLogin(DataDriverJXL.getTestConfig("SF_Username_UI"), DataDriverJXL.getTestConfig("SF_Password_UI"));
		//*[@id="00O5A000006cv3a_NAME"]/div[2]/a/span
	}

	@Test(description="All Projects")
	public void TestScript_002_Sanity() throws ParseException 
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		waitTime(2);
		DashboardAllProjects DAP=new DashboardAllProjects();
		clickOn(DAP.DrpDashboards_AllProjects);
		String GeneratedTime=getText("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");
		passTest(" Time " +GeneratedTime);	
		waitTime(2);
		clickOn(DAP.Clicking_AllProj_Retrieved);
		waitTime(2);
		clickOn(DAP.Closing_AllProj_Retr);
		waitTime(2);
		clickOn(DAP.Clicking_AllProj_SchdtoRet);
		waitTime(2);
		clickOn(DAP.Closing_AllProj_SchdtoRe);
		waitTime(2);
		clickOn(DAP.Clicking_PastDue);
		waitTime(2);
		clickOn(DAP.Closing_PastDue);
		waitTime(2);
		clickOn(DAP.Clicking_PNP);
		waitTime(2);
		clickOn(DAP.Closing_PNP);
		waitTime(2);
		clickOn(DAP.Clicking_NotRecoverable);
		waitTime(2);
		clickOn(DAP.Closing_NotRecov);
		waitTime(2);
		verifyElementPresent("Retrieval Rate - Retrieval Rate ;xpath~//*[@id='dvRetrievalInventoryHeader']");
		waitTime(2);
		/*verifyElementPresent("% of recoverable - % of recoverable ;xpath~//*[@id='dvRetrievalInventoryHeader']/div']");
		waitTime(2);*/
		verifyElementPresent("In Retrieval Rate section - Retrieved ;xpath~//*[@id='divRetInvRet']");
		waitTime(2);
		verifyElementPresent("In Retrieval Rate section - Retrieved And Scheduled ;xpath~//*[@id='divRetInvRetSch']");
		waitTime(2);

		/*String GeneratedTime1=getText("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");
		try {
			String Spname="Get_DB_LastUpdationDate";
			DBInterface Db=new DBInterface();
			Db.connectDBServer("jdbc:jtds:sqlserver://epidevsql.cd6nk8avjbps.us-east-1.rds.amazonaws.com/EpiconnectV3", "master", "EpicDb123");
			statement = conn.prepareCall("{call "+Spname+"}");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	/*String CurrentExecutedTime;
		//Login

		// Home page - Get the Time- String
		String sTimeFromSite = getText("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");

		String startTime="2018-09-04 04:28:32";
		Date date1=(Date) new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startTime);

		Date date=new Date(0);
		DateFormat df= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


		//us madrid date format to format the date

		df.setTimeZone(TimeZone.getTimeZone("US/Pacific"));

		System.out.println("Date and Time : "+ df.format(date));

		Date date2=(Date) new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(df.format(date));

		System.out.println("Date 2:" +"\t"+date2);

		long diff=(date2.getTime()-date1.getTime())/(60*60*1000);

		System.out.println(diff);

		if(diff > 2){
		System.out.println("Job is running for more than 2 hours");
		System.out.println("Send Email notifications");
		SendEmailNotify();
		}

		// Date covert into time String

		//Create the logic to find the 2 hour differece

		//If it is 2 hours difference


		}*/
	/*DashboardAllProjects DAP=new DashboardAllProjects();
		clickOn(DAP.DrpDashboards_AllProjects);
		String GeneratedTime1=getText("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");
		try {
			String Spname="Get_DB_LastUpdationDate";
			DBInterface Db=new DBInterface();
			Db.connectDBServer("jdbc:jtds:sqlserver://epidevsql.cd6nk8avjbps.us-east-1.rds.amazonaws.com/EpiconnectV3", "master", "EpicDb123");
			statement = conn.prepareCall("{call "+Spname+"}");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	//}
	/*GeneratedTime = GeneratedTime.replace("Generated:", "");
		GeneratedTime = GeneratedTime.trim();*/
	//Date date1= new Date(GeneratedTime);
	//DateFormat df= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/*	//Date date = Calendar.getInstance().getTime();  
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
        String strDate = dateFormat.format(date);  
        System.out.println("Converted String: " + strDate); */

	/*Date date1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startTime);
        Date date=new Date();
		DateFormat df= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");*/
	/*Date date1= (Date) new SimpleDateFormat("dd/MM/yyyy").parse(GeneratedTime); 
	 */
	/*		List<WebElement> list=driver.findElements(By.xpath("//*[@id='lblheading']/div"));

		for (int j = 0; j < list.size(); j++) {
			{
				list.get(j).getText();
			} 
		}
		verifyElementPresent("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");
		verifyElementPresent("Retrieval Details - Retrieval Details ;xpath~//div[contains(@id,'dvRetrievalHeader')]");
		verifyElementPresent("Retrieval Inventory - Retrieved ;css~#svgdivCom .doughnutText");
		verifyElementPresent("Retrieval Inventory - Retrieved And Scheduled ;css~#svgdivCom .doughnutTextCount");

		WebElement TargetElement=driver.findElement(By.xpath("//*[@id='lblheading']/div"));
		String getValue=TargetElement.getAttribute("value");
		//verifyElementPresent("Retrieved by Month - Retrieved by Month ;xpath~//*[@id='dvRetrievalByMonthHeader']");
		List<WebElement> checkboxes=getFindElementsList("Filter By Project - Select All ;xpath~//*[@id='lblchkall']/p");
			passTest("Selected List of Projects - Total Projects "+checkboxes.size());
			System.out.println(getFindElementsCount("Filter By Project - Project Counts ;xpath~//*[@id='mrrProjects']/li"));
		double RetTotal = 0;
		String sReturnTot="";
		double RetTotal1 = 0;
		String sReturnTot1="";
		String Totalcharts=getText("Retreival Total Charts ;css~#RetTotCharts");
		Totalcharts=Totalcharts.replaceAll(",", "").replaceAll(" ", "");
		String[] ChartCount=Totalcharts.split(":");

		try {
			RetTotal = Integer.parseInt(ChartCount[1]);
			sReturnTot = Double.toString(Math.floor((RetTotal)));

			//RetTotal = (ChartCount[1]);
			//
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(RetTotal>0)
		{
			passTest("Retrieval Inventory - Total Charts"+sReturnTot);
		}
		else
		{
			failTest("Retrieval Inventory - Total Charts");
		}
	}

	private void SendEmailNotify() {
		// TODO Auto-generated method stub

	}

	 */
	@Test(description="By Project")
	public void TestScript_003_Sanity() 
	{
		DashboardsByProject ProjProg=new DashboardsByProject();
		clickOn(ProjProg.DrpDashboards);
		waitTime(3);
		clickOn(ProjProg.DrpDashboards_ByProject);
		waitTime(3);
		verifyElementPresent("By Project - By Project ;xpath~//*[@id='lblheading']");
		verifyElementPresent("By Project - RETRIEVAL ;xpath~//*[@id='dvRetrieval']/div/strong");
		verifyElementPresent("By Project - CODING ;xpath~//*[@id='dvChartAudit']/div");
		verifyElementPresent("By Project - ATTESTATION ;xpath~//*[@id='dvAttestation']/div");
		//String GeneratedTime=getText("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");
		String GeneratedTime=getText("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");
		passTest(" Time " +GeneratedTime);
		waitTime(3);
		//System.out.println("Printing" + GeneratedTime.getAttribute("value"));

		//*[@id='chkchart'] Show Charts checkbox
		//verifyElementPresent("Select All - Select All ;xpath~//*[@id='lblchkall']/p");
		WebElement ChkShowCharts = driver.findElement(By.id("chkchart"));
		for(int i=0; i<2; i++) {
			ChkShowCharts.click();
			waitTime(3);
			System.out.println(ChkShowCharts.isSelected());
		} 
		waitTime(3);
		/*	WebElement ChkselectAll = driver.findElement(By.name("chkselectAll"));
		for(int i=0; i<2; i++) {
			ChkselectAll.click();
			waitTime(2);
			System.out.println(ChkselectAll.isSelected());
		} 
		waitTime(3);*/
		//List<WebElement> checkBoxes = driver.findElements(By.xpath("//input[@type='Checkbox']"));/*	

		/*List<WebElement> ChkselectAll = driver.findElements(By.name("chkselectAll"));	
		// WebElement ChkShowCharts = driver.findElement(By.id("chkchart"));
		for(int i=0; i<ChkselectAll.size(); i=i+3){
			ChkselectAll.get(i).click();

		}
		int checkedCount=0, uncheckedCount=0;
		for(int i=0; i<ChkselectAll.size(); i++){
			System.out.println(i+" checkbox is selected "+ChkselectAll.get(i).isSelected());
			if(ChkselectAll.get(i).isSelected()){
				checkedCount++;
			}else{
				uncheckedCount++;
			}
		}
		System.out.println("number of selected checkbox: "+checkedCount);
		System.out.println("number of unselected checkbox: "+uncheckedCount);*/
	}
	@Test(description="Retrieval Project Summary")
	public void TestScript_004_Sanity() 
	{
    
		RetProjectSummary RPS= new RetProjectSummary();
		clickOn(RPS.Drp_Retrieval_selectingRetrieval_menu);	
		waitTime(3);
		clickOn(RPS.Drp_Retrieval_selectingRetrProjSummary_menu);
		waitTime(3);
		clickOn(RPS.Clicking_RetrProjRetrieved);
		waitTime(2);
		clickOn(RPS.Closing_RetrProj_Retr);
		waitTime(2);
		clickOn(RPS.Clicking_RetrProj_SchdtoRet);
		waitTime(2);
		clickOn(RPS.Closing_RetrProj_SchdtoRe);
		waitTime(2);
		clickOn(RPS.Clicking_PastDue);
		waitTime(2);
		clickOn(RPS.Closing_PastDue);
		waitTime(2);
		clickOn(RPS.Clicking_PNP);
		waitTime(2);
		clickOn(RPS.Closing_PNP);
		waitTime(2);
		clickOn(RPS.Clicking_NotRecoverable);
		waitTime(2);
		clickOn(RPS.Closing_NotRecov);
		waitTime(2);
		
		/*verifyElementPresent("Generated Time - Generated Time ; xpath~//*[@id='lblheading']/div");
		WebElement TargetElement=driver.findElement(By.xpath("//*[@id='lblheading']/div"));
		String getValue=TargetElement.getAttribute("value");*/
		verifyElementPresent("Project Summary - Project Summary ;xpath~//*[@id='lblheading']");
		verifyElementPresent("Chase Status - Chase Status ;xpath~//div[contains(@id,'dvRetrievalHeader')]");
		verifyElementPresent("Retrieval Rate - Retrieved ;css~#svgdivCom .doughnutText");
		verifyElementPresent("Retrieval Rate - Retrieved And Scheduled ;css~#svgdivCom .doughnutTextCount");
		verifyElementPresent("Retrieved by Month - Retrieved by Month ;xpath~//*[@id='dvRetrievalByMonthHeader']");
		verifyElementPresent("Select All Project Name - Select All Project Name ;xpath~//*[@id='mrrprojects']/label/input");
		WebElement SelectAllProjectName = driver.findElement(By.className("SelectAllProjectName"));
		for(int i=0; i<2; i++) {
			SelectAllProjectName.click();
			waitTime(2);
			//FluentWait obj=new flu
			System.out.println(SelectAllProjectName.isSelected());
		}
		List<WebElement> checkboxes=getFindElementsList("Filter By Project - Select All Project Name ;xpath~//*[@id='mrrprojects']/label/input");
		passTest("Selected List of Projects - Total Projects "+checkboxes.size());
		double RetTotal = 0;
		String sReturnTot="";
		double RetTotal1 = 0;
		String sReturnTot1="";
		String Totalcharts=getText("Retreival Total Charts ;css~#RetTotCharts");
		Totalcharts=Totalcharts.replaceAll(",", "").replaceAll(" ", "");

		String[] ChartCount=Totalcharts.split(":");

		try {
			RetTotal = Integer.parseInt(ChartCount[1]);
			sReturnTot = Double.toString(Math.floor((RetTotal)));

			//RetTotal = (ChartCount[1]);
			//
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(RetTotal>0)
		{
			passTest("Retrieval Inventory - Total Charts"+sReturnTot);
		}
		else
		{
			failTest("Retrieval Inventory - Total Charts");
		}
		clickOn(RPS.Clicking_On_MoreDetails_Link);
		waitTime(2);
	}

	

	/*List<WebElement> checkboxes=getFindElementsList("Filter By Project - Select All Project Name ;xpath~//*[@id='mrrprojects']/label/p");
		passTest("Selected List of Projects - Total Projects "+checkboxes.size());*/
	// Finding the checkbox by its class
	/*List<WebElement> list = driver.findElements(By.className("inspectorChkSpan"));
		//Getting the number of checkboxes available.
		int count =list.size();
		//Iterating the loop from first checkbox to last checkbox
		for(int i=0;i<count;i++){
			String sValue=list.get(i).getAttribute("value");
			if(sValue.equalsIgnoreCase("inspectorChkSpan")){
				list.get(i).click();
				break;
			}
		}*/


	//System.out.println(getFindElementsCount("Filter By Project - Project Counts ;xpath~//*[@id='mrrProjects']/li"));

	@Test(description="Provider Status")
	public void TestScript_005_Sanity() 
	{ 
		ProviderStatus PS=new ProviderStatus();
		clickOn(PS.Drp_Retrieval_selectingRetrieval_menu);
		clickOn(PS.Lst_Epiconnect_Retrieval_selectingProviderStatus);
		waitForAjaxToFinish();
		waitTime(2);
		verifyElementPresent("Select All Project Name - Select All Project Name ;xpath~//*[@id='mrrprojects']/label/input");
		WebElement SelectAllProjectName = driver.findElement(By.className("SelectAllProjectName"));
		for(int i=0; i<2; i++) {
			SelectAllProjectName.click();
			waitTime(2);
			//FluentWait obj=new flu
			System.out.println(SelectAllProjectName.isSelected());
		}
		verifyElementPresent("Retrieval Rate - Retrieval Rate ;xpath~//*[@id='dvChartRetrievalHeader']");
		waitTime(2);
		verifyElementPresent("Provider Engagement - Provider Engagement ;xpath~//*[@id='dvProviderEngagementHeader']");
		waitTime(2);
		verifyElementPresent("Chase Status - Chase Status ;xpath~//*[@id='dvChartByStatusHeader']");
		waitTime(2);
		verifyElementPresent("Provider By Status - Provider By Status ;xpath~//*[@id='dvProviderByStatusHeader']");
		waitTime(2);
		verifyElementPresent("Past Due and Aging -  Past Due and Aging ;xpath~//*[@id='dvPastDueHeader']");
		waitTime(2);
		verifyElementPresent("Retrieval Breakout - Retrieval Breakout ;xpath~//*[@id='dvRetrievalBreakoutHeader']");
		waitTime(2);
		verifyElementPresent("Provider Not Participating - Provider Not Participating ;xpath~//*[@id='dvPNPHeader']");
		waitTime(2);
		verifyElementPresent("Not Recoverable Reasons - Not Recoverable Reasons ;xpath~//*[@id='dvNRNHeader']");
		waitTime(2);
	}
	@Test(description="Retrieved To Date")
	public void TestScript_006_Sanity() 
	{ 
		RetrievedToDate RTD= new RetrievedToDate();
		clickOn(RTD.Drp_Retrieval_selectingRetrieval);
		clickOn(RTD.Drp_Retrieval_RetrievedToDatemenu);
		waitForAjaxToFinish();
		waitTime(15);
		verifyElementPresent("Retrieval Graph - Retrieval Graph ;xpath~//*[@id='dvRetrievalGraphHeader']");
	}
	@Test(description="Scheduled Inflow")
	public void TestScript_007_Sanity() 
	{ 
		ScheduledInflow SI= new ScheduledInflow();
		clickOn(SI.Drp_Retrieval_selectingRetrieval_menu);
		waitTime(4);
		clickOn(SI.Lst_Epiconnect_Retrieval_selectingScheduledInflow);
		waitForAjaxToFinish();
		waitTime(4);
		verifyElementPresent("Sceduled For Retrieval - Scheduled For Retrieval;xpath~//*[@id='lblheading']");
		//verifyElementPresent("Scheduled For Retrieval - Scheduled For Retrieval;xpath~//*[@id='dvSDHeader']");
	}
	@Test(description="PNP Management")
	public void TestScript_008_Sanity() 
	{ 
		PNPManagement PNPMgmt=new PNPManagement();
		clickOn(PNPMgmt.Drp_Retrieval_selectingRetrieval_Retrievalmenu);
		waitTime(2);
		clickOn(PNPMgmt.Drp_Retrieval_selectingPnp_Mgmt);
		verifyElementPresent("PNP MANAGEMENT - PNP MANAGEMENT;xpath~//*[@id='lblheading']");
		waitForAjaxToFinish();
		waitTime(6);
		clickOn(PNPMgmt.Click_ExporttoExcel);
		waitTime(5);
		//WebDriver wd;
		//wd= new Chromedriver() ;
		/*List <WebElement> col= PNPMgmt.findElements(By.xpath(".//*[@id='tblPNPLocations_Header']/tr[2]/th[1]"));
		System.out.println("No of cols are : " +col.size());
		List <WebElement> row= wd.findElements(By.xpath(".//*[@id='tblPNPLocations_body']/tr[25]/td[6]"));*/
		sendKeys(PNPMgmt.Entering_Location_ID, "L-01151096");
		waitTime(2);
		webElement.sendKeys(Keys.TAB);
		waitTime(2);
		clickOn(PNPMgmt.Click_Location_ID);
		waitForAjaxToFinish();
		waitTime(6);
		clickOn(PNPMgmt.Click_Location_Profile);
		waitForAjaxToFinish();
		waitTime(15);
		clickOn(PNPMgmt.Click_Providers_Tab);
		waitTime(2);
		clickOn(PNPMgmt.Click_Provider_Link);
		waitTime(10);
		clickOn(PNPMgmt.Close_Provider_Popup_Link);
		waitTime(5);
		clickOn(PNPMgmt.Click_PNPCharts_Profile);
		waitForAjaxToFinish();
		waitTime(15);
		clickOn(PNPMgmt.Click_PNPAppointment_Tab);
		waitTime(4);
		clickOn(PNPMgmt.Click_PNPInvoices_Tab);
		waitForAjaxToFinish();
		waitTime(5);
	}

	@Test(description="Search")
	public void TestScript_009_Sanity() 
	{ 
		Search Sch=new Search();
		clickOn(Sch.Drp_Retrieval_selectingRetrieval_Searchmenu);
		waitTime(2);
		clickOn(Sch.Drp_Retrieval_selectingSearch);
		waitTime(2);
		clickOn(Sch.Click_LocationID_Searchicon);
		waitForAjaxToFinish();
		waitTime(5);
		sendKeys(Sch.Entering_PracticeName, "WIELENGA MEDICAL GROUP");
		webElement.sendKeys(Keys.ENTER);
		waitForAjaxToFinish();
		waitTime(3);
		clickOn(Sch.Click_Location_ID);
		waitForAjaxToFinish();
		waitTime(3);
		clickOn(Sch.Click_Providers_Tab);
		waitForAjaxToFinish();
		waitTime(3);
		clickOn(Sch.Click_Provider_Link);
		waitForAjaxToFinish();
		waitTime(3);
		clickOn(Sch.Close_SchProvider_Popup_Link);
		waitTime(5);
		clickOn(Sch.Click_Charts_Profile);
		waitForAjaxToFinish();
		waitTime(10);
		clickOn(Sch.Click_Appointment_Tab);
		waitForAjaxToFinish();
		waitTime(3);
		clickOn(Sch.Click_Invoices_Tab);
		waitTime(5);

		/*WebDriver wd = null;
		List <WebElement> col= wd.findElements(By.xpath(".//*[@id='tblPNPLocations_Header']/tr[2]/th[1]"));
		System.out.println("No of cols are : " +col.size());
		List <WebElement> row= wd.findElements(By.xpath(".//*[@id='tblPNPLocations_body']/tr[25]/td[6]"));*/

		//sendKeys(xpath, Text);
	}
	@Test(description="Coding Project Summary")
	public void TestScript_010_Sanity() 
	{ 
		CodingProjectSummary CPS=new CodingProjectSummary();
		clickOn(CPS.Drp_ClickCoding_menu);
		verifyElementPresent("Coding - Coding ;Linktext~Coding");
		waitTime(3);
		//verifyElementPresent("Tools - Tools ;xpath~//*[@id='acc309']/a')]");
		clickOn(CPS.Drp_SelectingCodingProjSummary_menu);
		verifyElementPresent("Project Summary - Project Summary ;Linktext~Project Summary"); 
		verifyElementPresent("Chart Audit Inventory - Chart Audit Inventory ;xpath~//*[@id='dvChartAuditInventoryHeader']");
		verifyElementPresent("Complete - Complete ;xpath~//*[@id='dvcodingComp']");
		verifyElementPresent("Complete + Ready to Deliver - Complete + Ready to Deliver ;xpath~//*[@id='dvcodingCompDeliver']");
		verifyElementPresent("Complete by Month - Complete by Month ;xpath~//*[@id='dvChartAuditCompleteByMonthHeader']");
		/*WebElement ChkselectAll = driver.findElement(By.name("chkselectAll"));
		for(int i=0; i<2; i++) {
			ChkselectAll.click();
			waitTime(2);
			System.out.println(ChkselectAll.isSelected());
		} */
		/*List<WebElement> checkboxes=getFindElementsList("Filter By Project - Select All ;xpath~//*[@id='lblchkall']/p");
		passTest("Selected List of Projects - Total Projects "+checkboxes.size());
		System.out.println(getFindElementsCount("Filter By Project - Project Counts ;xpath~//*[@id='mccProjects']/li"));*/
		double CodTotal = 0;
		String sReturnTot="";
		/*double RetTotal1 = 0;
		String sReturnTot1="";*/
		String Totalcharts=getText("Coding Total Charts ;css~#CodTotCharts");
		Totalcharts=Totalcharts.replaceAll(",", "").replaceAll(" ", "");

		String[] ChartCount=Totalcharts.split(":");

		try {
			//if(ChartCount[1].length()>=1)
			String[] ChartCountPercent=ChartCount[1].split(" ");

			//CodTotal = Integer.parseInt(ChartCount[1]);
			CodTotal=Integer.parseInt(ChartCountPercent[0]);
			sReturnTot = Double.toString(Math.floor((CodTotal)));

			//RetTotal = (ChartCount[1]);
			//
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(CodTotal>0)
		{
			passTest("Chart Audit Inventory - Total Charts"+sReturnTot);
		}
		else
		{
			failTest("Chart Audit Inventory  - Total Charts");
		}
	}
	@Test(description="Charts Delivered")
	public void TestScript_011_Sanity() 
	{
		ChartsDelivered CD= new ChartsDelivered();
		clickOn(CD.Drp_ClickCoding_menu);
		clickOn(CD.Drp_Coding_selectingChartsDelivered_menu);
		waitForAjaxToFinish();
		waitTime(10);
		verifyElementPresent("Chart Delivered - Chart Delivered ;xpath~//*[@id='lblheading']");
		double ChartsDelivCompleteTotal = 0;
		String CodingCompleteTot="";
		String TotalComplecharts=getText("Coding Complete Charts ;css~#divMCCCompleted");
		//TotalComplecharts=TotalComplecharts.replaceAll(",", "").replaceAll(" ", "") ;
		//String[] ChartCount=null;
		if(TotalComplecharts.toString().length()>0)
		{
			passTest("Verified :Chart Audit - Progress - Complete "+TotalComplecharts);
		}
		else
		{
			failTest("Chart Audit - Progress  - Complete");
		}
	}
	//String[] ChartCount=TotalComplecharts.split(":");
	/*try {
			String[] ChartCountPercent=ChartCount[1].split(" ");
			ChartsDelivCompleteTotal=Integer.parseInt(ChartCountPercent[0]);
			//ChartsDelivCompleteTotal = Integer.parseInt(ChartCount[1]);
			CodingCompleteTot = Double.toString(Math.floor((ChartsDelivCompleteTotal)));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	//String[] ChartCount=TotalComplecharts.split(":"); 
	/*	double ChartsReadytoDeliver = 0;
			String CodingRTDTot="";*/

	@Test(description="Special Projects")
	public void TestScript_012_Sanity()
	{
		CodingSpecialProjects CSP= new CodingSpecialProjects();
		clickOn(CSP.Drp_ClickCoding_menu);
		verifyElementPresent("Coding - Coding ;Linktext~Coding");
		waitTime(3);
		//verifyElementPresent("Tools - Tools ;xpath~//*[@id='acc309']/a')]");
		clickOn(CSP.Drp_Selecting_SpecialProjects_menu);
		verifyElementPresent("Special Projects - Special Projects ;Linktext~Special Projects"); 
		//*[@id='lblchkall']/input
		verifyElementPresent("Select All - Select All ;xpath~//*[@id='lblchkall']/p");
		String GeneratedTime=getText("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div");
		WebElement ChkselectAll = driver.findElement(By.name("chkselectAll"));
		for(int i=0; i<2; i++) {
			ChkselectAll.click();
			waitTime(2);
			System.out.println(ChkselectAll.isSelected());
		} 
		verifyElementPresent("Chart Audit Inventory - Chart Audit Inventory ;xpath~//*[@id='dvSPChartAuditHeader']");
		verifyElementPresent("Complete - Complete ;xpath~//*[@id='divSplReadyDeliverComplete']");
		verifyElementPresent("Complete + Ready to Deliver - Complete + Ready to Deliver ;xpath~//*[@id='divSplReadyDeliver']");
		verifyElementPresent("Complete by Month - Complete by Month ;xpath~//*[@id='dvSPCompleteByMonthHeader']");
		List<WebElement> checkboxes=getFindElementsList("Filter By Project - Select All ;xpath~//*[@id='lblchkall']/p");
		passTest("Selected List of Projects - Total Projects "+checkboxes.size());
		System.out.println(getFindElementsCount("Filter By Project - Project Counts ;xpath~//*[@id='mccProjects']/li"));
		double SpecialProjTotal = 0;
		String SpecialProjReturnTot="";
		/*double RetTotal1 = 0;
		String sReturnTot1="";*/
		String Totalcharts=getText("Coding Total Charts ;css~#SplTotCharts");
		Totalcharts=Totalcharts.replaceAll(",", "").replaceAll(" ", "");
		String[] ChartCount=Totalcharts.split(":");
		try {
			SpecialProjTotal = Integer.parseInt(ChartCount[1]);
			SpecialProjReturnTot = Double.toString(Math.floor((SpecialProjTotal)));
			//RetTotal = (ChartCount[1]);
			//
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(SpecialProjTotal>0)
		{
			passTest("Chart Audit Inventory - Total Charts"+SpecialProjReturnTot);
		}
		else
		{
			failTest("Chart Audit Inventory  - Total Charts");
		}
	}
	@Test(description="Attestation")
	public void TestScript_013_Sanity()
	{
		CodingAttestation CATT=new CodingAttestation();
		clickOn(CATT.Drp_ClickCoding_menu);
		verifyElementPresent("Coding - Coding ;Linktext~Coding");
		waitTime(3);
		clickOn(CATT.Drp_Coding_selecting_Attestation_menu);
		waitTime(5);
		verifyElementPresent("Attestation - Attestation ;Linktext~Attestation");
		waitTime(2);
		//verifyElementPresent("Tools - Tools ;xpath~//*[@id='acc309']/a')]");

		/*WebElement ChkselectAll = driver.findElement(By.name("chkselectAll"));
		for(int i=0; i<2; i++) {
			ChkselectAll.click();
			waitTime(2);
			System.out.println(ChkselectAll.isSelected());
		} */

		//verifyElementPresent("Attestation Inventory - Attestation Inventory ;xpath~//*[@id='dvAttestationInventoryHeader']");

		double AttTotal = 0;
		String sAttReturnTot="";
		String AttestTotalcharts=getText("Coding Total Charts ;css~#AttesTotCharts");
		AttestTotalcharts=AttestTotalcharts.replaceAll(",", "").replaceAll(" ", "");

		String[] ChartCount=AttestTotalcharts.split(":");

		try {
			//if(ChartCount[1].length()>=1)
			String[] ChartCountPercent=ChartCount[1].split(" ");

			//CodTotal = Integer.parseInt(ChartCount[1]);
			AttTotal=Integer.parseInt(ChartCountPercent[0]);
			sAttReturnTot = Double.toString(Math.floor((AttTotal)));

			//RetTotal = (ChartCount[1]);
			//
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(AttTotal>0)
		{
			passTest("Attestationt Inventory - Total Charts"+sAttReturnTot);
		}
		else
		{
			failTest("Attestationt Inventory  - Total Charts");
		}
		waitTime(2);

		/*List<WebElement> checkboxes=getFindElementsList("Filter By Project - Select All ;xpath~//*[@id='lblchkall']/p");
		passTest("Selected List of Projects - Total Projects "+checkboxes.size());
		System.out.println(getFindElementsCount("Filter By Project - Project Counts ;xpath~//*[@id='mccProjects']/li"));*/

	}
	@Test(description="Data Extract")
	public void TestScript_014_Sanity() 
	{ 
		QueryBuilder NorQB=new QueryBuilder();
		clickOn(NorQB.Drp_ToolsPage_selectingTools_QueryBuildermenu);
		clickOn(NorQB.Lst_Epiconnect_Tools_selectingQueryBuilder);
		waitForAjaxToFinish();
		waitTime(2);
		GenericComponentImplementation.clickOn(NorQB.selecting_NewQuery_Btn);
		GenericComponentImplementation.waitTime(2);
		waitForElementVisible(NorQB.selecting_NewQuery_Btn);
		waitTime(2);
		/*clickOn(NorQB.selecting_NewQuery_Btn);
		waitForElementDisplay(NorQB.selecting_NewQuery_Btn);*/
		sendKeys(NorQB.Typetoadd_Query_Name, "Applecare");
		//sendKeys(NorQB.Typetoadd_Query_Name, "Clear");
		//sendKeys(NorQB.Typetoadd_Query_Name, getText("Applecare"));
		clickOn(NorQB.clickNext);
		clickOn(NorQB.SelectingAll);
		clickOn(NorQB.AddProjects);
		waitTime(2);
		clickOn(NorQB.ClickProjectsNext);
		clickOn(NorQB.ClickLaunchQuery);
		waitForAjaxToFinish();

		String RecordsGeneralcharts=getText("General Data Extract # Records ;xpath~//*[@id='tBodyDataExport']/tr[2]/td[3]");
		//String RecordsTotalcharts=getText("Optum PNP Data Extract # Records ;xpath~//*[@id='tBodyRetrievalDataExport']/tr[2]/td[3]");
		RecordsGeneralcharts=RecordsGeneralcharts.replaceAll(",", "").replaceAll(" ", "");
		String[] ChartCount = null;

		if(Integer.parseInt(RecordsGeneralcharts) >0)
		{
			passTest("General Data Extract - Total Charts"+RecordsGeneralcharts);
		}
		else
		{
			failTest("General Data Extract  - Total Charts");

		}
	}
	@Test(description="Optum Data Extract")
	public void TestScript_015_Sanity() 
	{ 
		OptumDataExtract OptumQB=new OptumDataExtract();
		clickOn(OptumQB.Drp_OptumToolsPage_selectingTools_QueryBuildermenu);
		clickOn(OptumQB.Lst_Epiconnect_Tools_selectingQueryBuilder);
		waitForAjaxToFinish();
		waitTime(2);
		GenericComponentImplementation.clickOn(OptumQB.selecting_NewQuery_Btn);
		GenericComponentImplementation.waitTime(2);
		waitForElementVisible(OptumQB.selecting_NewQuery_Btn);
		waitTime(2);
		/*clickOn(NorQB.selecting_NewQuery_Btn);
		waitForElementDisplay(NorQB.selecting_NewQuery_Btn);*/
		sendKeys(OptumQB.Typetoadd_Query_Name, "Optum data extract");
		//sendKeys(NorQB.Typetoadd_Query_Name, "Clear");
		//sendKeys(NorQB.Typetoadd_Query_Name, getText("Applecare"));
		clickOn(OptumQB.clickNext);
		clickOn(OptumQB.SelectingAll);
		clickOn(OptumQB.AddProjects);
		waitTime(2);
		clickOn(OptumQB.ClickProjectsNext);
		clickOn(OptumQB.ClickLaunchQuery);
		waitForAjaxToFinish();
		double RetDataExtractTotRecords = 0;
		String RetExtractTot="";
		/*double RetTotal1 = 0;
		String sReturnTot1="";*/

		String RecordsTotalcharts=getText("Optum Data Extract # Records ;xpath~//*[@id='tBodyDataExport']/tr[1]/td[3]");
		//String RecordsTotalcharts=getText("Optum PNP Data Extract # Records ;xpath~//*[@id='tBodyRetrievalDataExport']/tr[2]/td[3]");
		RecordsTotalcharts=RecordsTotalcharts.replaceAll(",", "").replaceAll(" ", "");
		String[] ChartCount = null;

		if(Integer.parseInt(RecordsTotalcharts) >0)
		{
			passTest("Optum Data Extract - Total Charts"+RecordsTotalcharts);
		}
		else
		{
			failTest("Optum Data Extract  - Total Charts");

		}

	}
	//*[@id='btnOptumQuery']

	@Test(description="Optum Retrieval Data Extract")
	public void TestScript_016_Sanity() 
	{
		OptRetrievalDataExtract ORDE= new OptRetrievalDataExtract();
		GenericComponentImplementation.clickOn(ORDE.selecting_Retrieval_Data_Extract_Tab);
		GenericComponentImplementation.clickOn(ORDE.selecting_NewQuery_Btn);
		GenericComponentImplementation.waitTime(2);
		waitForElementVisible(ORDE.selecting_NewQuery_Btn);
		/*clickOn(NorQB.selecting_NewQuery_Btn);
		waitForElementDisplay(NorQB.selecting_NewQuery_Btn);*/
		sendKeys(ORDE.Typetoadd_Query_Name, "OptumRetri data extract");
		//+CommonUtil.getCurrentTimeStamp("yyyymmddhhmmss"));
		//sendKeys(NorQB.Typetoadd_Query_Name, "Clear");
		clickOn(ORDE.clickNext);
		clickOn(ORDE.SelectingAll);
		clickOn(ORDE.AddProjects);
		waitTime(2);
		clickOn(ORDE.ClickProjectsNext);
		waitTime(2);
		clickOn(ORDE.Click_Retreieval_LaunchQuery);
		waitTime(5);

		double RetDataExtractTotRecords = 0;
		String RetExtractTot="";
		/*double RetTotal1 = 0;
		String sReturnTot1="";*/

		String RecordsTotalcharts=getText("Retrieval Data Extract # Records ;xpath~//*[@id='tBodyDataExport']/tr[1]/td[3]");
		RecordsTotalcharts=RecordsTotalcharts.replaceAll(",", "").replaceAll(" ", "");
		String[] ChartCount = null;

		if(Integer.parseInt(RecordsTotalcharts) >0)
		{
			passTest("Retrieval Data Extract - Total Charts"+RecordsTotalcharts);
		}
		else
		{
			failTest("Retrieval Data Extract  - Total Charts");

		}
	}
	@Test(description="Optum PNP Data Extract")
	public void TestScript_017_Sanity() 
	{ 
		PNPDataExtract OPNP = new PNPDataExtract();
		GenericComponentImplementation.clickOn(OPNP.selecting_PNP_Data_Extract_Tab);
		GenericComponentImplementation.clickOn(OPNP.selecting_NewQuery_Btn);
		GenericComponentImplementation.waitTime(2);
		waitForElementVisible(OPNP.selecting_NewQuery_Btn);
		waitTime(2);
		/*clickOn(NorQB.selecting_NewQuery_Btn);
		waitForElementDisplay(NorQB.selecting_NewQuery_Btn);*/
		sendKeys(OPNP.Typetoadd_Query_Name, "Optum PNP Data extract");
		//sendKeys(NorQB.Typetoadd_Query_Name, "Clear");
		clickOn(OPNP.clickNext);
		clickOn(OPNP.SelectingAll);
		clickOn(OPNP.AddProjects);
		waitTime(2);
		clickOn(OPNP.ClickProjectsNext);
		clickOn(OPNP.ClickLaunchQuery);
		waitForAjaxToFinish();

		double RetDataExtractTotRecords = 0;
		String RetExtractTot="";
		/*double RetTotal1 = 0;
		String sReturnTot1="";*/

		String RecordsTotalcharts=getText("Optum PNP Data Extract # Records ;xpath~//*[@id='tBodyDataExport']/tr[1]/td[3]");
		//String RecordsTotalcharts=getText("Optum PNP Data Extract # Records ;xpath~//*[@id='tBodyRetrievalDataExport']/tr[2]/td[3]");
		RecordsTotalcharts=RecordsTotalcharts.replaceAll(",", "").replaceAll(" ", "");
		String[] ChartCount = null;

		if(Integer.parseInt(RecordsTotalcharts) >0)
		{
			passTest("PNP Data Extract - Total Charts"+RecordsTotalcharts);
		}
		else
		{
			failTest("PNP Data Extract  - Total Charts");

		}
	}

	@Test(description="Case Management")
	public void TestScript_027_Sanity() 
	{ 
		HRACaseManagement CMgmt=new HRACaseManagement();
		
		GenericComponentImplementation.clickOn(CMgmt.ToolsPage_selectingTools_menu);
		waitTime(2);
		GenericComponentImplementation.clickOn(CMgmt.selectingTools_CaseManagement);
		waitTime(2);
		GenericComponentImplementation.clickOn(CMgmt.Entering_MemberID);
		waitForAjaxToFinish();
		waitTime(2);
		sendKeys(CMgmt.Entering_MemberID, "152847");
		webElement.sendKeys(Keys.ENTER);
		waitForAjaxToFinish();
		waitTime(3);
		GenericComponentImplementation.clickOn(CMgmt.Clicking_On_ExportToExcel);
		waitTime(3);
		verifyElementPresent("Emergent - Emergent ;xpath~//*[@id='dvurgency']/table/tbody/tr[2]/td[3]/b");
		waitTime(2);
		verifyElementPresent("Urgent - Urgent ;xpath~//*[@id='dvurgency']/table/tbody/tr[3]/td[3]/b");
		waitTime(2);
		verifyElementPresent("Non-Urgent - Non-Urgent ;xpath~//*[@id='dvurgency']/table/tbody/tr[4]/td[3]/b");
		waitTime(2);
		/*WebElement SelectAllProjectName = driver.findElement(By.className("SelectAllProjectName"));
		for(int i=0; i<2; i++) {
			SelectAllProjectName.click();
			waitTime(2);
			//FluentWait obj=new flu
			System.out.println(SelectAllProjectName.isSelected());
		}*/
	
		String ShowingMembers=getText("Showing Members; xpath~//*[@id='MemberCaseTable_info']");
		passTest("Showing Members Count, ShowingMembers");
	}

	
	//driver.findElement(By.id("userRegistrationForm:userName")).sendKeys("moogaprimo");
	//driver.findElement(By.id("userRegistrationForm:password")).clear();

	@Test(description="Chart Image Finder")
	public void TestScript_018_Sanity() 
	{   
		String[] MemberName ={"Stakely, Tyrone"};
		String[] ChartId ={"30084891984009088296"};
		ChartImageFinder CIF=new ChartImageFinder();
		clickOn(CIF.Drp_ToolsPage_selectingTools_menu);
		waitTime(2);
		verifyElementPresent("Tools - Tools ;Linktext~Tools");
		waitTime(2);
		//verifyElementPresent("Tools - Tools ;xpath~//*[@id='acc309']/a')]");
		clickOn(CIF.Lst_Epiconnect_Tools_selectingChartImageFinder);
		verifyElementPresent("Tools - Chart Image Finder ;Linktext~Chart Image Finder"); 
		waitTime(2);
		//verifyElementPresent("Showing number of Charts:xpath~//*[@id='RCFtbl_info']");
		clickOn(CIF.Switchingon_Inspector);
		for (int j=0; j < MemberName.length; j++)    
		{	
			String strval= MemberName[j];
			String strId =ChartId[j];
			passTest("strval : "+ strval);
			//driver.navigate().refresh();
			//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			waitForElementPresent("Member Name - Member Name ;Id~txtMemFName");
			waitTime(2);
			//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.id("txtMemFName")).sendKeys(strval);
			clickOn(CIF.btnrcfSearch);	
			passTest("Clicking on Search");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			waitForElementPresent("MemberNamelink - MemberNameLink;linkText~strval");
			waitTime(2);
			clickOn(CIF.strval);
			//waitForElementPresent(OR);
			//waitForElementPresent(By.linkText("Torres romo, Rosalba"));	
			driver.findElement(By.linkText("Stakely, Tyrone")).click();
			//clickOn(By.linkText("Test"));
			//clickOn(By.linkText("Torres romo, Rosalba"));
			/*waitForElementPresent(By.id("divMemberProfile"));
			clickOn(By.id("divMemberProfile"));

			waitForElementPresent(By.id("aInspectCharts"));
			clickOn(By.id("aInspectCharts"));

			waitForElementPresent(By.xpath("(//table[@id='tblcharts']/tbody/tr/td[2]/a)"));
			clickOn(By.xpath("(//table[@id='tblcharts']/tbody/tr/td[2]/a)"));*/


			//waitForElement(By.xpath("(//table[@id='tblcharts']/tbody/tr/td[2]/a)"));

			// Store the current window handle 
			/*String winHandleBefore = driver.getWindowHandle();

			//Perform the click operation that opens new window
			//Switch to new window opened
			for(String winHandle : driver.getWindowHandles()){
				System.out.println("Handling Windows:"+ winHandle);
				driver.switchTo().window(winHandle);
				System.out.println("Handling Windows:"+ driver.switchTo().window(winHandle));
				Thread.sleep(1000);
			}
			driver.close();
			driver.switchTo().window(winHandleBefore);
			driver.switchTo().defaultContent();
			waitForElementPresent(By.id("divClose"));
			clickOn(By.id("divClose"));
			WebElement element = driver.findElement(By.xpath("//div[@id='"+strId+"']/a"));
			for(int i=0;i<30;i++)
			{
				if(element.isDisplayed())
				{
					//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);


					clickOn(By.xpath("(//div[@id='"+strId+"']/a"));
					break;
				}
				else
				{
					Thread.sleep(1000); 
				}
			}
			// driver.navigate().refresh();
			driver.findElement(By.id("txtMemFName")).clear();
			Reporter.log("Downloading Chart");
			System.out.println("Downloading Chart");
		}*/
		}
	}
	@Test(description="HRA Member Status")
	public void TestScript_020_Sanity()
	{
		DBInterface Db=new DBInterface();
		Db.connectDBServer("jdbc:jtds:sqlserver://10.3.1.138/SFDC", "ESPL1464", "Episource123");
		int DbCount_Sta=Db.getTotalNoOfQuery_DB("SELECT * From EPIP_TraverseResult where ID in ('472','473','474')");
		waitTime(10);
		HRAMemberStatus HMS= new HRAMemberStatus();
		GenericComponentImplementation.clickOn(HMS.Drp_ClickHRA_menu);
		waitTime(2);
		//verifyElementPresent("HRA Status - HRA Status ;xpath~//*[@id='divHRAHeader']]");
		verifyElementPresent("Recent Progress - Recent Progress ;xpath~//*[@id='dvRecentProgressHeader']");
		verifyElementPresent("Conversion Rate - Conversion Rate ;xpath~//*[@id='dvConversionRateHeader']");
		clickOn(HMS.Clicking_HRA_MemberStatus_PreOutreach);
		waitTime(2);
		clickOn(HMS.Closing_HRA_MemberStatus_PreOutreach);
		waitTime(1);
		clickOn(HMS.Clicking_HRA_MemberStatus_MemberOutreach);
		waitTime(2);
		clickOn(HMS.Closing_HRA_MemberStatus_MemberOutreach);
		waitTime(2);
		clickOn(HMS.Clicking_HRA_MemberStatus_Scheduled);
		waitTime(2);
		clickOn(HMS.Closing_HRA_MemberStatus_Scheduled);
		waitTime(1);
		clickOn(HMS.Clicking_HRA_MemberStatus_VisitPerformed);
		waitTime(2);
		clickOn(HMS.Closing_HRA_MemberStatus_VisitPerformed);
		waitTime(1);
		clickOn(HMS.Clicking_HRA_MemberStatus_Declined);
		waitTime(2);
		clickOn(HMS.Closing_HRA_MemberStatus_Declined);
		waitTime(1);
		clickOn(HMS.Clicking_HRA_MemberStatus_ClientActionRequired);
		waitTime(1);
		clickOn(HMS.Closing_HRA_MemberStatus_ClientActReq);
		waitTime(2);
		double TotalMemCount = 0;
		int sReturnMemTotCount=0;
		double RetTotal1 = 0;
		String sReturnTot1="";
		String withoutCommaTotal="";
		String Totalcharts=getText("Total Members Count ;xpath~//*[@id='tblRetrievalLegends']/tfoot/tr[1]/td[2]");
		withoutCommaTotal=Totalcharts;
		Totalcharts=Totalcharts.replaceAll(",", "");
		System.out.println(Totalcharts);
		//String[] ChartCount=Totalcharts.split(":");

		try {

			sReturnMemTotCount=Integer.parseInt(Totalcharts);
			System.out.println(sReturnMemTotCount);

		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(sReturnMemTotCount>0 &( DbCount_Sta==sReturnMemTotCount))
		{
			passTest("Actual DB Count "+DbCount_Sta+" is matching with expected UI count :"+withoutCommaTotal);
		}
		else
		{
			failTest("Actual DB Count "+DbCount_Sta+" is matching not matching with expected UI count :"+withoutCommaTotal);
		}

		int UI_coun=0;//*[@id="tblRetrievalLegends"]
		String TotalMembers=getText("HRA Members Count - Total Members ;xpath~//*[@id='tblRetrievalLegends']/tfoot/tr[1]/td[2]/b");
		TotalMembers=TotalMembers.replaceAll(",", "").replaceAll(" ", "");
		 
		System.out.println("expected TotalMembers"+TotalMembers);
		System.out.println("Actual DBTotalMembers"+sReturnMemTotCount);
		String[] TotalMembersCount=null;
		if(Double.valueOf(TotalMembers)>0)
		{
			passTest("HRA Member Status - Total Members"+TotalMembers);
		}
		else
		{
			failTest("HRA Member Status - Total Members");
		}
		/*String ExpText=getText("");*/

		/*	UI_coun=Integer.parseInt(TotalMembers);
		if(DbCount_Sta==UI_coun)
		{
			passTest("UI count matching with Db count"+UI_coun);
		}
		else
		{
			failTest("failed");
		}	*/

	}


	@Test(description="HRA Scheduled and Performed")
	public void TestScript_021_Sanity()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HRAScheduledCompleted HRASC= new HRAScheduledCompleted();
		GenericComponentImplementation.clickOn(HRASC.Drp_ClickHRA_menu);
		waitForAjaxToFinish();
		waitTime(2);
		GenericComponentImplementation.clickOn(HRASC.Drp_HRA_selectingSchedComp_menu);
		waitTime(2);
		verifyElementPresent("SCHEDULED & PERFORMED - SCHEDULED & PERFORMED ;xpath~//*[@id='lblheading']");
		waitTime(2);
		verifyElementPresent("HRAs Completed by Month - HRAs Completed by Month ;xpath~//*[@id='lbltitle']");
		waitTime(2);
		verifyElementPresent("Scheduled HRAs - Scheduled HRAs ;xpath~//*[@id='Label1']");
		waitTime(2);
		verifyElementPresent("In Scope Membership - In Scope Membership ;xpath~//*[@id='dvScopeMembership']/b[2]");
		waitTime(2);
		String InScopeMemberCount=getText("InScope Member Count ;xpath~//*[@id='dvScopeMembership']/b[1]");
		waitTime(2);
		System.out.println("InScope Member Count");
		waitTime(2);
		verifyElementPresent("Visits Performed - Visits Performed ;xpath~//*[@id='dvHRACompleted']/b[2]");
		waitTime(2);
		String VisitsPerformed=getText("Visits Performed ;xpath~//*[@id='dvHRACompleted']/b[1]");
		waitTime(2);
		verifyElementPresent("Scheduled - Scheduled ;xpath~//*[@id='dvHRAScheduled']/b[2]");
		waitTime(2);
		String Scheduled=getText("Scheduled ;xpath~//*[@id='dvHRAScheduled']/b[1]");
		waitTime(2);
		verifyElementPresent("Completion Rate - Completion Rate ;xpath~//*[@id='dvCompletionRate']/b[2]");
		waitTime(2);
		String CompletionRate =getText("Completion Rate ;xpath~//*[@id='dvCompletionRate']/b[1]");
		waitTime(2);
		//Getting the Scheduled bar count values
		String Scheduledbarcounts=getText("Scheduled Bar Counts ;xpath~//*[@id='divScheduledGraphDays']");
		waitTime(2);
		//Selecting drop-down By Month and By Week in Visit Performed section.
		Select dropdown = new Select(driver.findElement(By.id("selview")));
		dropdown.selectByVisibleText("Week View");
		waitTime(2);
		dropdown.selectByVisibleText("Month View");
		waitTime(2);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		//Selecting drop-down By Month and By Week in Visit Performed section.
		Select VolByDelDatedropdown = new Select(driver.findElement(By.id("selDelivery")));
		dropdown.selectByVisibleText("Week View");
		waitTime(2);
		dropdown.selectByVisibleText("Month View");

		/*//Using Index logic Selecting drop-down By Month and By Week in Visit Performed section.				
		Select selDelivery = new Select(driver.findElement(By.id("selDelivery")));
		selDelivery.selectByVisibleText("Week View");
		selDelivery.selectByVisibleText("Month");
		selDelivery.selectByIndex(3);*/
	}

	@Test(description="HRA Client Action Required")
	public void TestScript_022_Sanity()
	{
		HRACAR HRACAR= new HRACAR();
		GenericComponentImplementation.clickOn(HRACAR.Drp_ClickHRA_menu);
		waitForAjaxToFinish();
		waitTime(5);
		GenericComponentImplementation.clickOn(HRACAR.Drp_HRA_selecting_ClientActionRequired_menu);
		waitTime(4);

		/*String CARTotal=getText("Total ; xpath~//*[@id='trtotal']/td[1]/b");
		passTest(" Total # of Members + CARTotal");*/
		//String DaysinCARS=getText("Days in Client Action Required Status:xpath~//*[@id='divDays']/svg");
		//System.out.println("CARTotal");*/
		//	verifyElementPresent("Client Action Required - Client Action Required ;xpath~//*[@id='lblheading']/text()");
		//verifyElementPresent("# of Members ;xpath~//*[@id='trheader']/td[1]/b)");
		//*[@id="Label1"] - Client Action Required

		//Getting total # of Members in Client Action Required
		/*String TotalMemCount=getText("Total ; xpath~//*[@id='trtotal']/td[1]/b");*/
		/*	TotalMemCount=TotalMemCount.replaceAll(",", "").replaceAll(" ", "");
		String[] TotalMembersCount=null;
		if(Double.valueOf(TotalMemCount)>0)
		{
			passTest("HRA Member Status - Total # of Members"+TotalMemCount);
		}
		else
		{
			failTest("HRA Member Status - Total # of Members");
		}*/
		/*double trtotal = 0;
		String strtotal="";
		double trtotal1 = 0;
		String strtotal1="";
		String Totalcharts=getText("Total # Of Members ;css~#trtotal");
		Totalcharts=Totalcharts.replaceAll(",", "").replaceAll(" ", "");

		String[] ChartCount=Totalcharts.split(":");

		try {
			trtotal = Integer.parseInt(ChartCount[1]);
			strtotal = Double.toString(Math.floor((trtotal)));

			//RetTotal = (ChartCount[1]);
			//
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(trtotal>0)
		{
			passTest("Client Action Required - Total # Of Members"+strtotal);
		}
		else
		{
			failTest("Client Action Required - Total # Of Members");
		}*/
	}


	@Test(description="HRA Status Detail")
	public void TestScript_023_Sanity()
	{
		HRAStatusDetail HRASS= new HRAStatusDetail();
		GenericComponentImplementation.clickOn(HRASS.Drp_ClickHRA_menu);
		waitForAjaxToFinish();
		waitTime(2);
		GenericComponentImplementation.clickOn(HRASS.Drp_HRA_selectingStatusSummary_menu);
		waitTime(5);
		//Selecting drop-down By Month and By Week in Visit Performed section.
		Select sortbydropdown = new Select(driver.findElement(By.id("selReason")));
		sortbydropdown.selectByVisibleText("Count");
		waitTime(2);
		sortbydropdown.selectByVisibleText("Reason Code");
		waitTime(2);

	}
	/*@Test(description="HRA Member Search")
public void TestScript_024_Sanity()
{
	HRAMemberSearch HRAMS=new HRAMemberSearch();
	GenericComponentImplementation.clickOn(HRAMS.Drp_ClickHRA_menu);
	waitTime(1);
	GenericComponentImplementation.clickOn(HRAMS.Drp_HRA_selectingMemSearch_menu);
	waitTime(2);
	GenericComponentImplementation.clickOn(HRAMS.SearchBtn_MemSearchPage);
}*/

	@Test(description="HRA Member Search")
	public void TestScript_025_Sanity() 
	{ 
		HRAMemberSearch HRAMS=new HRAMemberSearch();
		clickOn(HRAMS.Drp_ClickHRA_menu);
		waitForAjaxToFinish();
		waitTime(3);
		GenericComponentImplementation.clickOn(HRAMS.Drp_HRA_selectingMemSearch_menu);
		waitTime(3);
		verifyElementPresent("Member Search - Member Search ;xpath~//*[@id='lblheading']");
		GenericComponentImplementation.clickOn(HRAMS.SearchBtn_MemSearchPage);
		waitTime(3);
		GenericComponentImplementation.clickOn(HRAMS.Clicking_On_ExportToExcel);
		waitTime(2);
		sendKeys(HRAMS.Entering_ItemId, "2968986");
		webElement.sendKeys(Keys.ENTER);
		waitForAjaxToFinish();
		waitTime(2);
	}

	@Test(description="Log Out")
	public void TestScript_026_Sanity() 
	{ 
		Logout LO=new Logout();
		GenericComponentImplementation.clickOn(LO.Click_Button);
		waitTime(2);
		GenericComponentImplementation.clickOn(LO.Click_LogOut);
		driver.close();
		//closeBrowser();
	}

	@AfterMethod

	public void tearDown()
	{	 

	}
}

/*@Test(description="Retrieval Project Summary")
public void TestScript_002_Sanity() 
{   


WebElement SVG_Retrieved=findElement("Retrieval Inventory ;css~#svgdivCom .doughnutTextCount");
	////button[contains(text(),'Applecare')
	//clickOn(HP.Drp_HomePage_selectClient);
	//finding the number of projects available
	//List checkboxes=driver.findElements(By.xpath("//*[@id='lblchkall']/p"));
	List checkboxes=  getFindElementsList(";className~inspectorChkSpan");
	//inspectorChkSpan

	//verifyElementPresent("Retrieval Details - Retrieval Details;xpath~//div[contains(@id,'dvRetrievalHeader')]");
	//verifyElementPresent("Retrieval Inventory - Retrieved ;css~#svgdivCom .doughnutText");
	System.out.println("Total Projects "+checkboxes.size());

	////*[@id="acc309"]/a
	{
		List<WebElement> results = getFindElementsList("Filter By Project - Project Counts ;xpath~//*[@id='lblchkall']/p");
		for (WebElement result : results){
			List<WebElement> boxes = result.findElements(By.className("inspectorChkSpan"));
			passTest("Number of Projects");
			failTest("Number of Projects");
			int numberOfBoxes = ((CharSequence) boxes).length();

		}

	//List checkboxes=driver.findElements(By.xpath("//input[@type='checkbox']"));

	HomePage HP=new HomePage();
	CreateYourGoogleAccount CGA=new CreateYourGoogleAccount();
	 sendKeys(HP.Txt_EDPS_HomePage_UserName, DataDriverJXL.getTestData("QA_UserName"));
	//clickOn(HP.Btn_EDPS_HomePage_Next);
	//sendKeys(HP.Txt_EDPS_HomePage_UserName, DataDriverJXL.getTestData("QA_Password"));
	clickOn(HP.lbl_EDPS_HomePage_MoreOptions);
    waitForElementVisible(HP.lbl_EDPS_HomePage_MoreOptions_CreateAccount);
	mouseHover(HP.lbl_EDPS_HomePage_MoreOptions_CreateAccount);
	waitTime(2);
	clickOn(HP.lbl_EDPS_HomePage_MoreOptions_CreateAccount);

	clickOn(CGA.lbl_EDPS_HomePage_MoreOptions_CreateAccount_Birthday_Month);
	waitForElementVisible(CGA.lbl_EDPS_HomePage_MoreOptions_CreateAccount_Birthday_Month_Menu);
	mouseHover(CGA.lbl_EDPS_HomePage_MoreOptions_CreateAccount_Birthday_Month_Menu);
	waitTime(2);
	clickOn(CGA.lbl_EDPS_HomePage_MoreOptions_CreateAccount_Birthday_Month_Menu);
	clickOn(CGA.btn_EDPS_HomePage_MoreOptions_CreateAccount_NextSteps);
	verifyElementText(CGA.lbl_EDPS_HomePage_MoreOptions_CreateAccount_Name_Error, "You can't leave this empty."); 
}
 */



/*@Test(description="All P")
public void TestScript_032_Sanity() 
{

	DashboardAllProjects DAP=new DashboardAllProjects();
	clickOn(DAP.DrpDashboards_AllProjects);
	List <WebElement> dateBox = driver.findElements(By.xpath("//*[@id='lblheading']/div"));

    //Print all the which are sibling of the the element named as 'SELENIUM' in 'Popular course'
    for (WebElement webElement : dateBox) {
        System.out.println(webElement.getText());
    }     

	// Create object of SimpleDateFormat class and decide the format
	 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	 //get current date time with Date()
	 Date date = new Date(0);

	 // Now format the date
	 String date1= dateFormat.format(date);

	 // Print the Date
	 System.out.println("Current date and time is " +date1);
	//System.out.println(xpath~//*[@id='lblheading']/div");
	 System.out.println(driver.findElement(By.xpath("//*[@id='lblheading']/div"))); 
	 System.out.println(getFindElementsCount("Generated Time;xpath~//*[@id='lblheading']/div"));
	//verifyElementPresent("Generated Time - Generated Time ;xpath~//*[@id='lblheading']/div"); 
	//verifyElementText(OR, ExpectedText);
	waitTime(2);
}
 */