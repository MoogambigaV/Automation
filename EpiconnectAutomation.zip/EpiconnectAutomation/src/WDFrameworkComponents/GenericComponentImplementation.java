package WDFrameworkComponents;

import java.awt.List;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
//import org.apache.http.conn.HttpHostConnectException;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import Driver.TestDriver;
import WDUtilities.*;
public class GenericComponentImplementation extends CommonUtil
{
	//Global variables Initialization
	public static GenericComponentImplementation Test;
	public static WebDriver driver;
	public static String outputDirectory=null;
	public static String BaseDirectory=null;
	public static Boolean testFailure;
	public static String currentMethodName;
	public static String DPMethodName="";
	public static String currentBrowser;
	public static int screenshotcount=1;
	public static Properties properties;
	public static String Browser="";
	private String URL="";
	public static By Locator;
	public static String LocatorValue="";
	private static String LocatorDesc=null;
	public static WebElement webElement;    
	public static boolean acceptNextAlert = true;
	public static int ElementTimeout=0;
	public static String ResultFolderName="";
	public static int MethodCount=1;
	private enum browserType
	{
		CHROME,
		INTERNETEXPLORER,
		FIREFOX,
		OPERA 
	}
	private enum LocatorType
	{
		XPATH,
		CSS,
		TAGNAME,
		ID, 
		CLASSNAME,
		LINKTEXT,
		NAME,
		PATIALLNKTEXT
	}
	public  void getURL(String URL)
	{	   
		try
		{
			this.URL=URL;
			driver.get(URL);
			passTest("Navigate to :"+this.URL);
		}
		catch (Exception e) {
			e.printStackTrace();
			failTest("Unable to navigate to :"+this.URL);
		}	  
	}	    
	public void startUp()
	{
		createLogFile();
		new LogoAppender().logoAppender();      	 
	}
	private  void seleniumRCInject()
	{
		try
		{
			// GenericComponentImplementation.Selenium = new WebDriverBackedSelenium(GenericComponentImplementation.driver, this.URL);
			setLog("INFO","Now it gets Selenium Supported!");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			setLog("ERROR",e.toString());		  
		}

	}
	public WebDriver openBrowser(String Browser,String DownloadFolderPath)
	{
		browserType value=browserType.valueOf(Browser.toUpperCase().trim());	 
		currentBrowser=value.toString();
		setLog("INFO","Opening the browser...........! "+currentBrowser);
		try
		{    		
			switch(value)
			{    	
			case CHROME :
				File file = new File(".\\Drivers\\chromedriver.exe");
				System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
				System.out.println( file.getAbsolutePath());
				String downloadFilepath = DownloadFolderPath;

				Map<String, Object> chromePrefs = new HashMap<String, Object>();
				chromePrefs.put("profile.default_content_settings.popups", 0);
				chromePrefs.put("download.default_directory", downloadFilepath);
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", chromePrefs);
				options.addArguments("--test-type");
				options.addArguments("--no-sandbox");
				options.addArguments("--privileged");
				options.addArguments("start-maximized", "disable-popup-blocking");

				DesiredCapabilities cap = DesiredCapabilities.chrome();
				//setProxy(cap);
				cap.setPlatform(Platform.WINDOWS);
				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				cap.setCapability(ChromeOptions.CAPABILITY, options);
				driver= new ChromeDriver(cap);
				passTest("Opened Browser :"+Browser);
				break;
			case INTERNETEXPLORER:
				file = new File(".//Drivers//IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver=new InternetExplorerDriver();
				passTest("Opened Browser :"+Browser);
				break;
			case FIREFOX:
				file = new File("C:/Windows/geckodriver.exe");
				System.setProperty("webdriver.gecko.driver", file.getAbsolutePath());
				driver=new FirefoxDriver();
				passTest("Opened Browser :"+Browser);
				break;
			case OPERA:
				//driver=new OperaDriver();
				passTest("Opened Browser :"+Browser);
				break;
			}	
			seleniumRCInject();     
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			failTest("Unable to switch the Browser"+e.toString());			 
		}

		return driver;    	    	  
	}    
	@SuppressWarnings("incomplete-switch")
	public  void FindLocator(String Locator)
	{
		LocatorType Loctype =LocatorType.valueOf(Locator.toUpperCase().trim());
		setLog("INFO","Locator "+Locator+"parsed..!");
		try
		{    		
			switch(Loctype)
			{    	
			case XPATH :
				webElement=driver.findElement(By.xpath(LocatorValue));
				setLog("INFO",Locator+"Assigned");
				break;
			case NAME:
				webElement=driver.findElement(By.name(LocatorValue));
				setLog("INFO",Locator+"Assigned");
				break;
			case PATIALLNKTEXT:
				webElement=driver.findElement(By.partialLinkText(LocatorValue));
				setLog("INFO",Locator+"Assigned");
				break;
			case ID:
				webElement=driver.findElement(By.id(LocatorValue));
				setLog("INFO",Locator+"Assigned");
				break;
			case TAGNAME:
				webElement=driver.findElement(By.tagName(LocatorValue));
				setLog("INFO",Locator+"Assigned");
				break;
			case LINKTEXT:
				webElement=driver.findElement(By.linkText(LocatorValue));
				setLog("INFO",Locator+"Assigned");
				break;
			case CLASSNAME:
				webElement=driver.findElement(By.className(LocatorValue));
				setLog("INFO",Locator+"Assigned");
				break;
			}	   
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			failTest("Unable to Assign locator :"+e.toString());			 
		}    	    	  
	}
	public WebElement findElement(String ORLocator)
	{		 
			waitForElementDisplay(ORLocator);
			try	
			{
				WebDriverWait wait =new WebDriverWait(getDriver(), ElementTimeout);
				for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
				{
					ORDivider(ORLocator);
					setLog("Info", "Checking the Element visibility "+ORLocator);
					if(wait.until(ExpectedConditions.visibilityOfElementLocated(Locator)).isDisplayed())
					{
						setLog("INFO",LocatorDesc+" is visible..;)");
						try
						{  

							webElement=getDriver().findElement(Locator);
							wait =new WebDriverWait(getDriver(), ElementTimeout);
							passTest("Identified the WebElement :''"+LocatorDesc+"''");
							break;
						}
						catch(NoSuchElementException e)
						{
							e.printStackTrace();
							setLog("INFO", "NoSuchElement "+e.toString());				
						}
						catch (StaleElementReferenceException e) 
						{
							e.printStackTrace();
							setLog("INFO", "StaleElementReferenceException ");
						}
						catch(NoSuchWindowException e)
						{
							e.printStackTrace();
							failTest("FindElement on :''"+LocatorDesc+"''"+e.toString());	 			     
						}
						catch(WebDriverException e)
						{
							e.printStackTrace();
							setLog("INFO", "WebdriverException "+e.toString());			     
						}
						catch (Exception e) 
						{
							e.printStackTrace();
							failTest("FindElement on :''"+LocatorDesc+"''"+e.toString());	 
						}			
					}
					else
					{				 
						setLog("INFO","Waiting for Visibility of the Element "+LocatorDesc);
					}
					waitTime(1);
					if(Timeout>=ElementTimeout)
					{
						failTest("FindElement On:"+LocatorDesc);
						break;
					}
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				failTest("FindElement On:"+LocatorDesc+e.toString());
			}
			return webElement;
		}
 

	public static By switchBy(String LocatorValue)
	{
		LocatorType Loc=LocatorType.valueOf(LocatorValue.toUpperCase());
		switch(Loc)
		{
		case ID:
			Locator=By.id(GenericComponentImplementation.LocatorValue);
			setLog("INFO","ID:-" +GenericComponentImplementation.LocatorValue);
			break;
		case NAME:
			Locator=By.name(GenericComponentImplementation.LocatorValue);
			setLog("INFO","name:-" +GenericComponentImplementation.LocatorValue);
			break;
		case CLASSNAME:
			Locator=By.className(GenericComponentImplementation.LocatorValue);
			setLog("INFO","className:-" +GenericComponentImplementation.LocatorValue);
			break;
		case LINKTEXT:
			Locator=By.linkText(GenericComponentImplementation.LocatorValue);
			setLog("INFO","linkText:-" +GenericComponentImplementation.LocatorValue);
			break;
		case PATIALLNKTEXT:
			Locator=By.partialLinkText(GenericComponentImplementation.LocatorValue);
			setLog("INFO","partialLinkText:-" +GenericComponentImplementation.LocatorValue);
			break;
		case CSS:
			Locator=By.cssSelector(GenericComponentImplementation.LocatorValue);
			setLog("INFO","cssSelector:-" +GenericComponentImplementation.LocatorValue);
			break;
		case TAGNAME:
			Locator=By.tagName(GenericComponentImplementation.LocatorValue);
			setLog("INFO","tagName:-" +GenericComponentImplementation.LocatorValue);
			break;
		case XPATH:
			Locator=By.xpath(GenericComponentImplementation.LocatorValue);
			setLog("INFO","xpath:-" +GenericComponentImplementation.LocatorValue);
			break;
		default:
			failTest("Please use the following LocatorType in you OR:(ID/XPATH/TAGNAME/CSS/NAME/CLASSNAME/LINKTEXT/PATIALLNKTEXT)");
			break;
		}
		return Locator;
	}
	public static void ORDivider(String ORObj)
	{
		String LocType="";		
		try
		{
			if(ORObj.length()!=0||ORObj.equals(null))
			{
				System.out.println("1:"+ORObj.length());
				if(ORObj.contains(";"))
				{
					String[] obj1= ORObj.split(";");					
					LocatorDesc=obj1[0];
					LocatorValue= obj1[1];
					System.out.println(LocatorDesc);
					System.out.println(LocatorValue);
					setLog("info", LocatorDesc);
					if(LocatorValue.contains("~"))
					{
						String[] obj2= LocatorValue.split("~");					
						LocType=obj2[0];
						LocatorValue=obj2[1];
						System.out.println(LocType);
						System.out.println(LocatorValue);
						switchBy(LocType);
					} 
				}
				else
				{    					  					 
					failTest("Unknown Locator or Locator Description not ends with ;(i.e String name=More Options;xpath~//div[contains(text(),'More options')]");
					System.out.println(LocatorValue);
					System.out.println(Locator);
				}
			}
			else
			{		 
				failTest("OR object is not intialized in the assigned variable");
			}			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public static void sendKeys(String OR,String Text)
	{
		for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
		{
			try
			{				
				ORDivider(OR);
				webElement=getDriver().findElement(Locator);
				clearElement(OR);
				webElement.sendKeys(Text);
				passTest("Typed"+" in "+LocatorDesc ,Text);
				break;
			}
			catch(InvalidElementStateException e)
			{
				setLog("INFO", "InvalidElementStateException "+e.toString());
			}		
			catch(NoSuchElementException e)
			{
				setLog("INFO","Waiting for the Element :"+LocatorDesc);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				failTest("Typed '' "+Text+" '' in :"+LocatorDesc);
			}
			if(Timeout>=ElementTimeout)
			{
				failTest("Click On:"+LocatorDesc);
			}
			waitTime(1);
		}
	}
	public static void doubleClickOn(By OR)
	{
		try
		{
			Actions action = new Actions(getDriver());
			WebElement we1 = getDriver().findElement(OR);
			action.doubleClick(we1).build().perform();
			passTest("Double Click On :"+Locator);
			setLog("INFO","Mouse Hover :"+Locator);
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			failTest("Double Click On :"+Locator);
		}
	} 
	public static void clickOn(String OR)
	{
		waitForElementDisplay(OR);
		try	
		{
			WebDriverWait wait =new WebDriverWait(getDriver(), ElementTimeout);
			for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
			{
				ORDivider(OR);
				setLog("Info", "Checking the Element visibility "+OR);
				if(wait.until(ExpectedConditions.visibilityOfElementLocated(Locator)).isDisplayed())
				{
					setLog("INFO",LocatorDesc+" is visible..;)");
					try
					{  

						webElement=getDriver().findElement(Locator);
						wait =new WebDriverWait(getDriver(), ElementTimeout);
						webElement.click();
						passTest("Clicked on :''"+LocatorDesc+"''");
						break;
					}
					catch(NoSuchElementException e)
					{
						e.printStackTrace();
						setLog("INFO", "NoSuchElement "+e.toString());				
					}
					catch (StaleElementReferenceException e) 
					{
						e.printStackTrace();
						setLog("INFO", "StaleElementReferenceException ");
					}
					catch(NoSuchWindowException e)
					{
						e.printStackTrace();
						failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 			     
					}
					catch(WebDriverException e)
					{
						e.printStackTrace();
						setLog("INFO", "WebdriverException "+e.toString());			     
					}
					catch (Exception e) 
					{
						e.printStackTrace();
						failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 
					}			
				}
				else
				{				 
					setLog("INFO","Waiting for Visibility of the Element "+LocatorDesc);
				}
				waitTime(1);
				if(Timeout>=ElementTimeout)
				{
					failTest("Click On:"+LocatorDesc);
					break;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void clickOn(String OR,String ScrollDown)
	{
		waitForElementDisplay(OR);
		scrollTo(OR,ScrollDown);
		try
		{
			WebDriverWait wait =new WebDriverWait(getDriver(), ElementTimeout);
			for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
			{
				ORDivider(OR);
				setLog("Info", "Checking the Element visibility "+OR);
				if(wait.until(ExpectedConditions.visibilityOfElementLocated(Locator)).isDisplayed())
				{
					setLog("INFO",OR+" is visible..;)");
					try
					{  
						webElement=getDriver().findElement(Locator);
						wait =new WebDriverWait(getDriver(), ElementTimeout);
						webElement.click();
						passTest("Clicked on :''"+LocatorDesc+"''");
						break;
					}
					catch(NoSuchElementException e)
					{
						e.printStackTrace();
						setLog("INFO", "NoSuchElement "+e.toString());				
					}
					catch (StaleElementReferenceException e) 
					{
						e.printStackTrace();
						setLog("INFO", "StaleElementReferenceException ");
					}
					catch(NoSuchWindowException e)
					{
						e.printStackTrace();
						failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 			     
					}
					catch(WebDriverException e)
					{
						e.printStackTrace();
						setLog("INFO", "WebdriverException "+e.toString());			     
					}
					catch (Exception e) 
					{
						e.printStackTrace();
						failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 
					}			
				}
				else
				{				 
					setLog("INFO","Waiting for Visibility of the Element "+LocatorDesc);
				}
				waitTime(1);
				if(Timeout>=ElementTimeout)
				{
					failTest("Click On:"+LocatorDesc);
					break;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void clickCheckBox(String OR)
	{
		Boolean Checked=false;
		waitForElementDisplay(OR);
		WebDriverWait wait =new WebDriverWait(getDriver(), ElementTimeout);
		for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
		{
			ORDivider(OR);
			setLog("Info", "Checking the Element visibility "+OR);
			if(wait.until(ExpectedConditions.visibilityOfElementLocated(Locator)).isDisplayed())
			{
				setLog("INFO",OR+" is visible..;)");
				try
				{  
					webElement=getDriver().findElement(Locator);
					wait =new WebDriverWait(getDriver(), ElementTimeout);
					webElement.click();
					getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
					System.out.println("CHECKBOX iS CHECKED() :"+webElement.getAttribute("checked").toString());
					Checked=webElement.getAttribute("checked").equals("true");
					if(Checked)
					{
						passTest("Clicked on CheckBox :''"+LocatorDesc+"''");
					}
					else
					{
						failTest("Clicked on CheckBox :''"+LocatorDesc+"''");
					}
					break;
				}
				catch(NoSuchElementException e)
				{
					setLog("INFO", "NoSuchElement "+webElement +e.toString());				
				}
				catch (StaleElementReferenceException e) 
				{
					setLog("INFO", "StaleElementReferenceException ");

				}
				catch(NoSuchWindowException e)
				{
					failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 			     
				}
				catch(WebDriverException e)
				{
					setLog("INFO", "WebdriverException ");			     
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 
				}			
			}
			else
			{				 
				setLog("INFO","Waiting for Visibility of the Element"+OR);

			}
			waitTime(2);
			if(Timeout>=ElementTimeout)
			{
				failTest("Click On:"+OR);
			}
		}
	}
	public static void clickOnWithImplicitWait(String OR)
	{

		for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
		{
			ORDivider(OR);
			setLog("Info", "Checking the Element visibility "+OR);
			if(isElementPresent(OR)&&isElementDisplayed(OR))
			{
				setLog("INFO",OR+" is visible..;)");
				try
				{  
					webElement=getDriver().findElement(Locator);					 
					webElement.click();
					passTest("Clicked on :''"+LocatorDesc+"''");
					break;
				}
				catch(NoSuchElementException e)
				{
					setLog("INFO", "NoSuchElement "+e.toString());					 
				}
				catch (StaleElementReferenceException e) 
				{
					setLog("INFO", "StaleElementReferenceException ");				 
				}
				catch(ElementNotVisibleException e)
				{
					failTest("Element Not Visible Exception "+OR);
				}
				catch(WebDriverException e)
				{
					setLog("INFO", "Webdriver Exception "+e.toString());			     
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 
				}

			}
			else
			{				 
				setLog("INFO","Waiting for present & diplay of the Element "+OR);				
			}
			getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			if(Timeout>=ElementTimeout)
			{
				failTest("Click On:"+OR);
			}
		}

	}
	public static void clickOnElemnetBasedclickableState(String OR)
	{
		WebDriverWait wait =new WebDriverWait(getDriver(), ElementTimeout);
		for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
		{
			ORDivider(OR);
			setLog("Info", "Checking the Element visibility "+OR);
			if(wait.until(ExpectedConditions.visibilityOfElementLocated(Locator)).isDisplayed())
			{
				setLog("INFO",OR+" is visible..;)");
				try
				{  
					webElement=getDriver().findElement(Locator);
					wait =new WebDriverWait(getDriver(), ElementTimeout);
					setLog("Info", "Checking the Element clickable "+OR);
					wait.until(ExpectedConditions.elementToBeClickable(webElement));
					setLog("Info", OR+" Element is clickable ");
					webElement.click();
					passTest("Clicked on :''"+LocatorDesc+"''");
					break;
				}
				catch(NoSuchElementException e)
				{
					setLog("INFO", "NoSuchElement "+e.toString());
					waitTime(2); 
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					failTest("Clicked on :''"+LocatorDesc+"''"+e.toString());	 
				}

			}
			else
			{				 
				setLog("INFO","Waiting for Visibility of the Element "+LocatorDesc);
				waitTime(2);
			}
			if(Timeout>=ElementTimeout)
			{
				failTest("Click On:"+LocatorDesc);
			}
		}

	}
	public void clickedOnUsingJS(String OR)
	{
		try
		{
			ORDivider(OR);

		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void clickedOnActiveElement(String OR)
	{
		try
		{
			ORDivider(OR);

		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public static void clearElement(String OR)
	{
		waitForElementDisplay(OR);
		try
		{		 
			ORDivider(OR);
			webElement=getDriver().findElement(Locator);
			webElement.clear();
			setLog("INFO","Cleared Text Box :"+LocatorDesc);
		}
		catch(InvalidElementStateException e)
		{
			e.printStackTrace();
			failTest("Unable to cleared Text Box :"+LocatorDesc+" "+e.toString());

		}
		catch (Exception e) 
		{
			e.printStackTrace();
			failTest("Unable to cleared Text Box :"+LocatorDesc+" "+e.toString());
		}
	}
	public static void closeBrowser()
	{
		try
		{
			getDriver().close();
			passTest("Closed the Browser :"+currentBrowser);
		}
		catch(Exception e)
		{
			failTest("Unable to close it"+e.toString());
		}
	}
	public static void maximizeBrowser()
	{
		try
		{
			getDriver().manage().window().maximize();
			setLog("INFO","Maximized the Browser "+currentBrowser);
		}
		catch (Exception e) 
		{
			setLog("INFO","Unable to maximize the Browser "+currentBrowser+e.toString());
		}
	}
	public static String getText(String OR)
	{
		String Text="";	
		for(int Timeout=1;Timeout<GenericComponentImplementation.ElementTimeout;Timeout++)
		{
			try
			{
				ORDivider(OR);
				waitForElementVisible(OR);
				webElement=getDriver().findElement(Locator);
				Text= webElement.getText();
				setLog("INFO","Getting the text of :"+LocatorDesc);
				setLog("INFO","Successfully got the text :"+Text);
				return Text;
			}
			catch (StaleElementReferenceException e) 
			{
				setLog("INFO","StaleElement Exception gettext :"+Text+e.toString());
				waitTime(2);				
			}
			catch (Exception e) 
			{
				failTest("UnSuccessful gettext :"+Text+e.toString());
			}
			if(Timeout==60)
			{
				failTest("UnSuccessful gettext :"+Text);
				return Text;
			}
		}
		return Text;

	}
	public static String getAttribute(By OR, String AttributeName)
	{
		String ActualText="";
		try
		{
			ActualText=getDriver().findElement(OR).getAttribute(AttributeName);
			passTest("Got the Attribute value of"+AttributeName+" Locator :"+OR);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			failTest("Did not get the Attribute value of"+AttributeName+" Locator :"+OR);
		}
		return ActualText;
	}
	public static  Boolean isElementVisible(String OR)
	{		 
		getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		WebDriverWait wait =new WebDriverWait(getDriver(),2);	 
		try
		{	ORDivider(OR);
		setLog("Info", "Checking the Element visibility "+OR);
		if(wait.until(ExpectedConditions.visibilityOfElementLocated(Locator)).isDisplayed())
		{		
			setLog("INFO","isElementExist: " + LocatorDesc) ;
			return true;
		}
		else 
		{
			setLog("ERROR","isElementExist: " + LocatorDesc+" Could not find element");
			return false;
		}  
		}
		catch(ElementNotVisibleException e)
		{
			setLog("INFO","Element is not visible :("+LocatorDesc+e.toString());
			return false;
		}
		catch (TimeoutException e) 
		{
			setLog("INFO","Element is not visible :("+LocatorDesc+e.toString());
			return false;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	public static Boolean isTextPresentOnPage(String Text)
	{
		try
		{
			if( driver.getPageSource().contains(Text))
			{
				passTest(Text +" Text is present in the page");
			}
			else
			{
				failTest(Text +" Text is not present in the page");
			}
		}
		catch (Exception e) 
		{
			failTest(Text +"Text is not present in the page " +e.toString());
			e.printStackTrace();
		}
		return null;
	}   
	public  Boolean isTextNotPresent(String Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
		return null;
	}  
	public Boolean isCheckboxSelected(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
		return null;
	}
	public Boolean isCheckBoxNotSelected(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
		return null;
	}
	public void selectFromDropdownByIndex(WebElement OR,int Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}


	}
	public void selectFromDropdownByValue(String OR,int Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}   
	public static void selectFromDropdownByVisibleText(String OR,String Text)
	{
		waitForElementDisplay(OR);
		scrollTo(OR);
		for(int Timeout=0; Timeout<=ElementTimeout;Timeout++)
		{
			try
			{	
				ORDivider(OR);
				setLog("Info", "Checking the Element elementSelectionStateToBe "+Locator);
				new Select(getDriver().findElement(Locator)).selectByVisibleText(Text);
				passTest("Selected by visible text "+Text);	
				break;			
			}
			catch(NoSuchElementException e)
			{
				failTest("SelectFromdropdown doest not have the "+Text +" -Exception :"+e.toString());
				break;
			}
			catch(WebDriverException e)
			{
				setLog("INFO",""+e.toString());
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				failTest("Selected by visible text "+Text+e.toString());
			}
			if(Timeout>=ElementTimeout)
			{
				failTest("Click On:"+OR);
			}
		}
	}
	public static void switchToFrame(String OR)
	{	
		waitForElementDisplay(OR);
		try
		{
			ORDivider(OR);
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame(getDriver().findElement(Locator));
			passTest("Switched to the Frame :"+OR);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			failTest("Switched to the Frame :"+OR);
		}
	}
	public void deselectAll(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}  
	public void deselectFromDropdownByIndex(WebElement OR,int Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}

	}
	public void deselectFromDropdownByValue(String OR,int Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}   
	public void deselectFromDropdownByVisibleText(String OR,int Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}
	public Boolean isMultipleSelected(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
		return null;
	}  
	public List getFirstSelectedOption(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
		return null;
	}
	public static int getFindElementsCount(String OR)
	{
		waitForElementPresent(OR);
		java.util.List<WebElement> SList;
		int Count=0;
		try
		{
			ORDivider(OR);
			setLog("Info", "getting the similar Element counts "+OR);
			SList=getDriver().findElements(Locator);
			Count=SList.size();
			setLog("Info", "Succesfully got the similar Element counts :"+Count);
		}
		catch (Exception e) 
		{
          CommonUtil.failTest("Unable to find the similar Elements(FindElements)"+e.toString());
		}
		return Count;
	}
	public static java.util.List<WebElement> getFindElementsList(String OR)
	{
		waitForElementPresent(OR)	;
		java.util.List<WebElement> SList = null; 
		try
		{
			ORDivider(OR);
			setLog("Info", "getting the similar Element counts "+OR);
			SList=getDriver().findElements(Locator);
		 
			setLog("Info", "Succesfully got the similar Element counts :"+SList);
		}
		catch (Exception e) 
		{
          CommonUtil.failTest("Unable to find the similar Elements(FindElements)"+e.toString());
		}
		return SList;
	}
	public List getAllSelectedOptions(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
		return null;
	}   //table[@id="Searchtbl"]/tbody/tr
	public List getCountFindElements(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
		return null;
	}//*[@id="Searchtbl_info"] 


	public static void scrollTo(String OR)
	{
		try
		{
			ORDivider(OR);
			WebElement element = getDriver().findElement(Locator);
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(false);", element);
			setLog("INFO","Scroll to :"+OR);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			failTest("Scroll to Failed "+OR);
		}
	} 
	public static void scrollTo(String OR,String Scroll)
	{
		try
		{
			ORDivider(OR);
			WebElement element = getDriver().findElement(Locator);
			System.out.println("arguments[0].scrollIntoView("+Scroll+"");
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView("+Scroll+");", element);
			setLog("INFO","Scroll to :"+OR);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			failTest("Scroll to Failed "+OR);
		}
	} 
	public void keyPress(String OR,String Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}
	public void doubleclickOn(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}  
	public void rightclickOn(String OR,String Text)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}
	public void rightclickedOn(String OR)
	{
		try
		{

		}
		catch (Exception e) 
		{

		}
	}
	public void scriptTimeOut(int Time)
	{
		try
		{
			driver.manage().timeouts().setScriptTimeout(Time, TimeUnit.SECONDS);
		}
		catch (Exception e) 
		{

		}
	}  
	public void implicitWaitTime(int Time)
	{
		try
		{
			driver.manage().timeouts().implicitlyWait(Time, TimeUnit.SECONDS);
		}
		catch (Exception e) 
		{

		}

		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
	}
	public static void waitForAjaxToFinish() 
	{
		int Timeout=0;
		try
		{ 
			String WindowStatus="";
			setLog("INFO","Actual Window Size :"+WindowStatus);
			while (true)
			{
				Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor)getDriver()).executeScript("return jQuery.active == 0");
				if (ajaxIsComplete)
				{
					setLog("INFO","Ajax Loading is complete");
					break;
				}
				Timeout++;
				setLog("INFO","Ajax Loading....!");
				waitTime(1);
				WindowStatus = (String) ((JavascriptExecutor)getDriver()).executeScript("return document.readyState");
				if (WindowStatus.equals("complete"))
				{
					setLog("INFO","Other Loading is complete");
					break;
				}
				if(Timeout==ElementTimeout)
				{
					setLog("ERROR","Could not handle the Ajax load");
					break;
				}
			}
		}
		catch(Exception e)
		{
			setLog("Error","Ajax Loaded "+e.toString());
		}

	}
	public static void waitForAjaxToFinish(By OR) 
	{
		int Timeout=0;
		try
		{ 
			while (true)
			{
				Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor)driver).executeScript("return jQuery.active == 0");
				if (ajaxIsComplete){
					setLog("INFO","Ajax Loading is complete");
					break;
				}
				Timeout++;
				setLog("INFO","Ajax Loading....!");
				waitTime(1);
				if(Timeout==ElementTimeout)
				{
					setLog("ERROR","Did not handle the Ajax load");
					break;
				}
			}
			/*wait= new WebDriverWait(driver, 10);
				wait.until(new ExpectedCondition<Boolean>() 
				{ 
					public Boolean apply(WebDriver wdriver) 
					{ 
						setLog("INFO","Ajax Loading... ;)");
						return ((JavascriptExecutor) getDriver()).executeScript("return jQuery.active == 0").equals(true);
					}
				}); */	 

		}
		catch(Exception e)
		{
			setLog("Error","Ajax Loaded "+e.toString());
		}

	}
	public static void waitTime(int Time)
	{
		try
		{
			setLog("INFO","WaitTime : Waited for "+Time+" Seconds");
			Thread.sleep(Time*1000);			
		}
		catch (Exception e) 
		{
			setLog("INFO",e.toString());
		}
	}	
	public static void waitForElementPresent(String OR)
	{
		try
		{
			ORDivider(OR);
			setLog("INFO","WaitForElementPresent:Waiting for"+LocatorDesc+" Present");
			for (int second = 0;; second++)
			{
				if (second >= 60) 
					failTest("timeout"+OR);
				try
				{					
					if (isElementPresent(OR)) 						
						break; 
				} 
				catch (Exception e) 
				{
					setLog("INFO", e.toString());
				}
				waitTime(1);
			}	
		}
		catch(Exception e)
		{
			setLog("INFO", e.toString());
		}
	}
	public static void waitForElementVisible(String OR)
	{
		for (int second = 0;; second++)
		{
			try
			{
				ORDivider(OR);
				setLog("INFO","WaitForElementDisplayed:Waiting for "+LocatorDesc+" Display");
				try
				{					
					if (isElementVisible(OR)) 						
						break; 
				} 
				catch (Exception e) 
				{
					setLog("INFO", e.toString());
				}
				waitTime(1);
			}	

			catch(WebDriverException e)
			{
				setLog("INFO", e.toString());
				break;
			}
			catch(Exception e)
			{
				setLog("INFO", e.toString());
			}
			if (second >= 60) 
				failTest("timeout"+OR);
		}
	}
	public static void dragandDrop(String Source, String Destination)
	{
		String Src="";
		String Des="";
		ORDivider(Source);
		WebElement SourceWE=getDriver().findElement(Locator);
		Src=LocatorDesc;
		ORDivider(Destination);
		WebElement DestinationWE=getDriver().findElement(Locator);
		Des=LocatorDesc;
		try
		{
			Actions web =new Actions(getDriver());
			web.dragAndDrop(SourceWE, DestinationWE);
			passTest("Dragged From :"+Src+" Dropped to "+Des);			 	
		}
		catch (Exception e) {
			// TODO: handle exception
			failTest("Drag & Drop Exception "+e.toString());
		}
	}
	public static void waitForElementDisplay(String OR)
	{
		for (int second = 0;; second++)
		{
			try
			{
				ORDivider(OR);
				setLog("INFO","WaitForElementDisplayed:Waiting for "+LocatorDesc+" Display");
				try
				{					
					if (isElementDisplayed(OR)) 						
						break; 
				} 
				catch (Exception e) 
				{
					setLog("INFO", e.toString());
				}
				waitTime(1);
			}	

			catch(WebDriverException e)
			{
				setLog("INFO", e.toString());
				break;
			}
			catch(Exception e)
			{
				setLog("INFO", e.toString());
			}
			if (second >= 60) 
				failTest("timeout"+OR);
		}
	}
	@SuppressWarnings("unused")
	public static void waitForPagetoLoad(int Seconds)
	{
		for (int second = 0;; second++)
		{
			try
			{
				getDriver().manage().timeouts().pageLoadTimeout(Seconds,TimeUnit.SECONDS);
				setLog("INFO","Wait For Page Laoding :Implicitly Waiting for "+Seconds);
				break;
			}	
			catch(WebDriverException e)
			{
				e.printStackTrace();
				setLog("INFO", e.toString());
				break;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				setLog("INFO", e.toString());
			}
			if (second >= 60) 
				failTest("Page load timeout for:"+ Seconds);
			break;
		}
	}

	public static void verifyElementText(String OR, String ExpectedText)
	{

		try
		{
			setLog("INFO","WaitForElementDisplayed:Waiting for "+LocatorDesc+" Display");	
			try
			{					
				if (isElementDisplayed(OR)) 
				{
					String ActualText="";
					ORDivider(OR);
					ActualText=getText(OR).trim();
					setLog("INFO"," Element Text "+ActualText);
					setLog("INFO"," Expected:  "+ExpectedText);
					setLog("INFO"," Actual  :  "+ActualText);
					if(ActualText.equals(ExpectedText))
					{
						passTest("Verified the actual text :"+ActualText+" is matching :"+ExpectedText+" of Element "+LocatorDesc);

					}
					else
					{
						failTest("Verified the  actual text :"+ActualText+" is not matching :"+ExpectedText+" of Element "+LocatorDesc);
					}
				}
			} 
			catch (Exception e) 
			{
				setLog("INFO", e.toString());
				e.printStackTrace();
			}
			waitTime(1);
		}	

		catch(WebDriverException e)
		{
			setLog("INFO", e.toString());
			failTest("WebDriver Exception "+e.toString());	
		}
		catch(Exception e)
		{
			setLog("INFO", e.toString());
			failTest("WebDriver Exception "+e.toString());
		}		
	}
	public static void verifyElementPresent(String OR)
	{		
		try
		{
			setLog("INFO","WaitForElementDisplayed:Waiting for "+LocatorDesc+" Display");	
			try
			{				
				ORDivider(OR);
				if (isElementDisplayed(OR)) 
				{
					passTest("Verified the Actual Element  :"+LocatorDesc+"is present");
				}
				else
				{
					failTest("Verified the Actual Element  :"+LocatorDesc +"is not present");
				}

			} 
			catch(WebDriverException e)
			{
				setLog("INFO", e.toString());
				failTest("Verify Element Present WebDriver Exception "+e.toString());	
			}
			catch (Exception e) 
			{
				setLog("INFO", e.toString());
				e.printStackTrace();
				failTest("Verify Element Present WebDriver Exception "+e.toString());	
			}
			waitTime(2);
		}	

		catch(WebDriverException e)
		{
			setLog("INFO", e.toString());
			failTest("WebDriver Exception "+e.toString());
		}
		catch(Exception e)
		{
			failTest("Timeout "+OR +e.toString());
		}				
	}
	public static boolean isElementPresent(String OR) {
		try 
		{
			ORDivider(OR);
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);  
			driver.findElement(Locator);
			setLog("INFO","IsElementPresent "+LocatorDesc+" is present..Cool :)");
			return true;
		} 
		catch (NoSuchElementException e)
		{
			setLog("INFO","IsElementPresent "+LocatorDesc+" is not present.. :(");
			return false;
		}
	}
	public static boolean isElementDisplayed(String OR) {
		try 
		{
			ORDivider(OR);
			getDriver().findElement(Locator).isDisplayed();
			setLog("INFO","IsElementDisplayed "+LocatorDesc+" is displayed..Cool :)");
			return true;
		} catch (NoSuchElementException e) {
			setLog("INFO","IsElementDisplayed "+LocatorDesc+" is not displayed.. :(");
			return false;
		}
	}


	public static boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}
	public static void verifyIsElementEditable(By OR) 
	{		 	 
		try
		{
			WebElement ele=getDriver().findElement(OR);
			String readonly =ele.getAttribute("readonly");
			if(!readonly.equals(null))
			{			
				failTest("Verify the Element is not Editable : "+LocatorDesc+" ");	
			}		 	 		 
		}	
		catch(InvalidElementStateException e)
		{
			failTest("Verify the Element is not Editable : "+LocatorDesc+" ");	
		}
		catch(WebDriverException e)
		{
			setLog("ERROR", e.toString());
			failTest("WebDriver Exception "+e.toString());
		}	
		catch(NullPointerException e)
		{
			//setLog("INFO", e.toString());
			passTest("INFO","Verify the Element is Editable : "+LocatorDesc+" ");		
		}

		catch(Exception e)
		{
			//failTest("Timeout "+OR +e.toString());
		}		
	}
	public static void verifyIsElementNotEditable(By OR) 
	{		 	 
		try
		{
			WebElement ele=getDriver().findElement(OR);
			String readonly =ele.getAttribute("readonly");
			if(!readonly.equals(null))
			{
				passTest("INFO","Verify the Element is not Editable : "+LocatorDesc+" ");

			}
			else
			{
				failTest("Verify the Element is Editable : "+LocatorDesc+" ");	
			}		 	 		 
		}	
		catch(WebDriverException e)
		{
			setLog("INFO", e.toString());
			failTest("WebDriver Exception "+e.toString());
		}
		catch(Exception e)
		{
			failTest("Timeout "+OR +e.toString());
		}		
	}

	public static String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
	public void getDownLoadFromURL(String OR,String URL) throws MalformedURLException, IOException
	{
		//WebElement dr=driver.findElement(By.xpath("//a[@title='Software Testing in PDF']"));
		/* 	System.out.println(dr.getAttribute("href"));
		    	String urlss=dr.getAttribute("href");*/
		URLConnection http = new URL( URL).openConnection();

		// Start copying!
		InputStream in = http.getInputStream();
		try 
		{
			OutputStream out = new FileOutputStream("D://testingsample2.pdf");
			try 
			{
				byte[] buf = new byte[512];
				int read;

				while ((read = in.read(buf)) > 0)
					out.write(buf, 0, read);
			} 
			finally 
			{
				out.close();
			}
		}
		finally 
		{
			in.close();
		}
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public static void setDriver(WebDriver driver) {
		TestDriver.driver = driver;
		setLog("INFO","Driver has been initiated!");
	}
	public static void mouseHover(By Locator1,By Locator2) {
		try
		{
			Actions action = new Actions(driver);
			WebElement we1 = driver.findElement(Locator1);
			WebElement we2 = driver.findElement(Locator2);
			action.moveToElement(we1).perform();
			action.moveToElement(we2).click().perform();
			//action.moveToElement(we).moveToElement(driver.findElement(Locator)).build().perform();
			passTest("Mouse Hover :"+Locator);
			setLog("INFO","Mouse Hover :"+Locator);
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
	public static void mouseHover(String OR) {
		try
		{
			ORDivider(OR);
			WebDriverWait wait=new WebDriverWait(getDriver(), 60);
			Actions action = new Actions(getDriver());
			WebElement we1 =getDriver().findElement(Locator);

			waitForPageLoad();			
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(Locator));
			wait.until(ExpectedConditions.visibilityOfElementLocated(Locator));
			action.moveToElement(we1).moveToElement(driver.findElement(Locator)).build().perform();
			passTest("Mouse Hover :"+LocatorDesc);
			setLog("INFO","Mouse Hover :"+LocatorDesc);
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			getDriver().switchTo().parentFrame();
			failTest("mouse over failed LocatorDesc "+LocatorDesc);
		}

	}
	public static Boolean waitForPageLoad()	
	{ 
		Wait<WebDriver> wait = new WebDriverWait(getDriver(), 30);

		System.out.println("Current Window State  : "+ String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));

		return wait.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				System.out.println("Current Window State  : "+ String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));
				return String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")).equals("complete");
			}
		});	
	}


}

