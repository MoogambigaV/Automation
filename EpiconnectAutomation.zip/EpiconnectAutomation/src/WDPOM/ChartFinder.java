package WDPOM;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ChartFinder {
	
	// TODO Auto-generated method stub
			private WebDriver driver;
			  private String baseUrl;
			  private boolean acceptNextAlert = true;
		private StringBuffer verificationErrors = new StringBuffer();
			  private Actions action;

			  @BeforeClass(alwaysRun = true)
			  
			  public void setUp() throws Exception {
				  
			System.setProperty("webdriver.chrome.driver","D:\\Seleni\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			
			// Create a new instance of the Firefox driver
					 
		System.out.println("Opening a Browser");
	// Maximize the window.
						
	driver.manage().window().maximize();
	System.out.println("Maximize");
				  
	//  System.setProperty("webdriver.gecko.driver","D://software_/geckodriver-v0.11.1-win64/geckodriver.exe");
			   // driver = new FirefoxDriver();
			    baseUrl = "https://epiconnect.com/";
			
			    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			  }
					 
		
	@SuppressWarnings("null")
			@Test
			  public void testChartFinderNew() throws Exception {
			    driver.get(baseUrl + "/Account/Signin.aspx?ReturnUrl=%2fdefault.aspx#MRR/RCF.aspx");
			    //Enter Username
			    driver.findElement(By.id("UserName")).clear();
			    driver.findElement(By.id("UserName")).sendKeys("moogambiga@episource.com");
			    Reporter.log("Entering Username");
			 
				// Enter Password
			    driver.findElement(By.id("Password")).clear();
			    driver.findElement(By.id("Password")).sendKeys("Scooby@88");
			    Reporter.log("Entering Password");
			    System.out.println("Entering Password");
			    // Click Login Button
			    clickOn(By.id("LoginButton")) ;
			    Reporter.log("LoginButton");
			    System.out.println("Logging In");
			     waitForElement(By.xpath("(//button[@type='button'])[4]"));
			     clickOn(By.xpath("(//button[@type='button'])[4]"));
			    waitForElement(By.linkText("OptumCare"));
			    // ERROR: Caught exception [ERROR: Unsupported command [focus | link=Optum | ]]
			    clickOn(By.linkText("OptumCare"));
			    // ERROR: Caught exception [ERROR: Unsupported command [mouseOver | link=Tools | ]]
			    Reporter.log("OptumCare Client");
			    
	String[] MemberName ={"Truex, Ana","Raby, Alvera"};
	String[] ChartId ={"C-DH6X87","C-DH6X8C"};
			    clickOn(By.linkText("Tools"));
			    Reporter.log("Tools");
			    System.out.println("Clicking Tools");
			    waitForElement(By.linkText("Chart Image Finder"));		    
			    clickOn(By.linkText("Chart Image Finder"));	   
			    Reporter.log("Chart Image Finder");
			    //System.out.println("P : "+MemberName.length);
			    for (int j=0; j < MemberName.length; j++)    
			    {	
			    
			    String strval= MemberName[j];
			    String strId =ChartId[j];
				
			    
			    
	System.out.println("strval : "+ strval);
				//driver.navigate().refresh();
				
			    //driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			   
			 waitForElement(By.id("txtMemFName"));
			   //driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			    
			  driver.findElement(By.id("txtMemFName")).sendKeys(strval);
			  clickOn(By.id("btnrcfSearch"));	
			  Reporter.log("Clicking on Search");
			  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			  waitForElement(By.linkText(strval));
			  clickOn(By.linkText(strval));
			    //waitForElement(By.linkText("Naab, Michael"));		

	   
	     	   // clickOn(By.linkText("Naab, Michael"));
			    waitForElement(By.id("divMemberProfile"));
			    clickOn(By.id("divMemberProfile"));
			    
			    waitForElement(By.id("aInspectCharts"));
			    clickOn(By.id("aInspectCharts"));
			    
			    waitForElement(By.xpath("(//table[@id='tblcharts']/tbody/tr/td[2]/a)"));
			    clickOn(By.xpath("(//table[@id='tblcharts']/tbody/tr/td[2]/a)"));
			    
			    Thread.sleep(1000);
			    //waitForElement(By.xpath("(//table[@id='tblcharts']/tbody/tr/td[2]/a)"));
			    // Store the current window handle 
	         String winHandleBefore = driver.getWindowHandle();

			    // Perform the click operation that opens new window
			    // Switch to new window opened
			    for(String winHandle : driver.getWindowHandles()){
			    	 System.out.println("Handling Windows:"+ winHandle);
			    	 driver.switchTo().window(winHandle);
	System.out.println("Handling Windows:"+ driver.switchTo().window(winHandle));
	Thread.sleep(1000);
			    }
	driver.close();
	 driver.switchTo().window(winHandleBefore);
	driver.switchTo().defaultContent();
	waitForElement(By.id("divClose"));
	clickOn(By.id("divClose"));
			   
	//((JavascriptExecutor)driver).executeScript("scroll(0,300)"); 
			    //clickOn(By.className("switchery switchery-default switcheryoff/small"));
			   // WebElement element = 

	//driver.findElement(By.xpath("//div[@id='30037267314004325829']/a"));
			     WebElement element = driver.findElement(By.xpath("//div[@id='"+strId+"']/a"));
			   for(int i=0;i<30;i++)
			    {
			    	if(element.isDisplayed())
			    	{
			    		 //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			    		  

	clickOn(By.xpath("(//div[@id='"+strId+"']/a"));
			    		 break;
			    	}
			    	else
			    	{
			    	    Thread.sleep(1000); 
			    	}
			    }
			   // driver.navigate().refresh();
			    driver.findElement(By.id("txtMemFName")).clear();
			   Reporter.log("Downloading Chart");
			    System.out.println("Downloading Chart");
			}
			    	
				  
			    //clickOn(By.linkText("30037267314004325829"));
			    //pdfDownload();
			    // ERROR: Caught exception [ERROR: Unsupported command [getAllWindowTitles |  | ]]
			    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | Docman_121516151920827 - PDFDownload.ashx | ]]
			
			//LOGOUT
				

	//driver.findElement(By.xpath("/html/body/nav/div/div[1]/div/div/div[2]/div[1]/button[2]")).click();
				

	//System.out.println("Clicking Dropdown");
				

	//driver.findElement(By.xpath("/html/body/nav/div/div[1]/div/div/div[2]/div[1]/ul/li[5]/a")).click();
				

	//System.out.println("Log Out");
				//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				//driver.navigate().back();
			 }
			 
	 @Test(invocationCount = 100)
			  public void downloadingCharts() {
			  }
			  
			  /*@Test(threadPoolSize = 5, invocationCount = 10)
			  public void concurrencyTest() {
			     System.out.print(" " + Thread.currentThread().getId());
			  } */

			  @AfterClass(alwaysRun = true)
			  public void tearDown() throws Exception {
				 //driver.close();
			  // driver.quit();
			    String verificationErrorString = verificationErrors.toString();
			    if (!"".equals(verificationErrorString)) {
			    	Assert.fail(verificationErrorString);
			    }
			  }

			  private boolean isElementPresent(By by) {
			    try {
			      driver.findElement(by);
			      return true;
			    } catch (NoSuchElementException e) {
			      return false;
			    }
			  }

			  private boolean isAlertPresent() {
			    try {
			      driver.switchTo().alert();
			      return true;
			    } catch (NoAlertPresentException e) {
			      return false;
			    }
			  }

			  private String closeAlertAndGetItsText() {
			    try {
			      Alert alert = driver.switchTo().alert();
			      String alertText = alert.getText();
			      if (acceptNextAlert) {
			        alert.accept();
			      } else {
			        alert.dismiss();
			      }
			      return alertText;
			    } finally {
			      acceptNextAlert = true;
			    }
			    
			  }
			
		 public void waitForElement(By locator) throws InterruptedException
			  {
				  for (int second = 0;; second++) {
				    	if (second >= 60) 
				    		Assert.fail("timeout");		    	
				    	try { 
				    		
	if (isElementPresent(locator))
				    		
	break;
		} 
	catch (Exception e) 
				    	{	

			    		
				    	}
				    	

	Thread.sleep(1000);
				    	
	Reporter.log("<font color='green>Click on:"+locator); 
	System.out.println("Waiting for :"+locator);
				    }

			  }
		 public void clickOn(By locator) throws 

	InterruptedException  
		  {
			  for (int second = 0;; second++) {
			    	if (second >= 60) 
			    		Assert.fail("timeout");		    	
			    	try { 
			    		if(isElementPresent(locator))
			    			
	driver.findElement(locator).click();
			 Reporter.log("<font color='green>Click on:"+locator);   		   
	System.out.println("Click on:"+locator);
			    			
	break;
			  } 
			catch (Exception e) 
			    	{		
			    		Thread.sleep(1000);
			    	}
			    	Reporter.log("<font color='green>Click on:"+locator); 
			    	
			    	System.out.println("Waiting for :"+locator);
			    }
		  }
			  public void mouseOver(By locator) throws InterruptedException  
			  {
				  for (int second = 0;; second++) {
				    	if (second >= 60) 
				    		Assert.fail("timeout");		    	
				    	try { 
				    		
	if (isElementPresent(locator))
				    		
	action = new Actions(driver);
	WebElement we = driver.findElement(locator);
	action.moveToElement(we).build().perform();
	Reporter.log("<font color='green>Click on:"+locator); 
	System.out.println("Mouse Over:"+locator);
	break;
		} 
	catch(Exception e) 
			{	
	Thread.sleep(1000);
			}
	Reporter.log("<font color='green>Click on:"+locator); 
	System.out.println("Waiting for :"+locator);
				    }
		  }
			  public void pdfDownload() 

	throws InterruptedException
			  { 
				  String winHandleBefore = driver.getWindowHandle();

				    // Perform the click operation that opens new window

				    // Switch to new window opened
				    for(String winHandle : driver.getWindowHandles()){
				        

	driver.switchTo().window(winHandle);
				        

	System.out.println("Handling Windows:"+ driver.switchTo().window(winHandle));
				    }
				    
				    			   
			  }
		 
	}



