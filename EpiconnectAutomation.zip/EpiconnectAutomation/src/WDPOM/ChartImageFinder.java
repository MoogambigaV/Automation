package WDPOM;

public class ChartImageFinder {

 	//String Drp_ToolsPage_selectingChartFinder="Menu Selection;xpath~//button[@type='button'][4]";
 	
	public String Drp_ToolsPage_selectingTools_menu="Menu Selection;Linktext~Tools";
	//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
	public String Lst_Epiconnect_Tools_selectingChartImageFinder="Select Chart Image Finder;Linktext~Chart Image Finder";
	public String Switchingon_Inspector="Switching On Inspector;Id~aInspectCharts";
	public String btnrcfSearch="Enter the data to be Searched;Id~btnrcfSearch";
	public String strval="String name Searched;Id~strval";
	}
