package WDPOM;

public class ChartsDelivered {

	public String Drp_ClickCoding_menu="Menu Selection;Linktext~Coding";
	public String Drp_Coding_selectingChartsDelivered_menu="Menu Selection;Linktext~Charts Delivered";
	public String GeneratedTime="Generated Time;xpath~//*[@id='lblheading']/div";
}
