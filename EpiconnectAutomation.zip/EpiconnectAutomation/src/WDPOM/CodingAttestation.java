package WDPOM;

public class CodingAttestation {
	public String Drp_ClickCoding_menu="Selecting Coding;Linktext~Coding";
	public String Drp_Coding_selecting_Attestation_menu="Selecting Attestation;Linktext~Attestation";
}
