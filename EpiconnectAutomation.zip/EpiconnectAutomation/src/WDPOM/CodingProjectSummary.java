package WDPOM;

public class CodingProjectSummary {
public String Drp_ClickCoding_menu="Selecting Coding;Linktext~Coding";
	//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
	public String Drp_SelectingCodingProjSummary_menu="Select Coding Project Summary;Linktext~Project Summary";
	}

