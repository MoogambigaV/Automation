package WDPOM;

public class CodingSpecialProjects 
	{
		public String Drp_ClickCoding_menu="Menu Selection;Linktext~Coding";
		//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
		public String Drp_Selecting_SpecialProjects_menu="Select Special Projects;Linktext~Special Projects";
	}


