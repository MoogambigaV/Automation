package WDPOM;

public class CreateYourGoogleAccount 
{
	public String lbl_EDPS_HomePage_MoreOptions_CreateAccount_Birthday_Month="BirthDay;xpath~//*[@id='BirthMonth']/div[1]";
	public String lbl_EDPS_HomePage_MoreOptions_CreateAccount_Birthday_Month_Menu="BirthDay Month;xpath~//*[@id=':4']/div";
	public String btn_EDPS_HomePage_MoreOptions_CreateAccount_NextSteps="Next Steps;id~submitbutton";
	public String lbl_EDPS_HomePage_MoreOptions_CreateAccount_Name_Error="Name Errors;id~errormsg_0_LastName";
}
