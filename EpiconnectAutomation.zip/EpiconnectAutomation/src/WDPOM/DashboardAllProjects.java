package WDPOM;

public class DashboardAllProjects {
        public String DrpDashboards_AllProjects="Select All Projects;LinkText~Dashboards";
        
        public String Clicking_AllProj_Retrieved="Clicking Retrieved breakouts;xpath~//a[@data-target='#dvRetrieved']";
        public String Closing_AllProj_Retr="Closing Retrieved Pop-up;xpath~//*[@id='dvRecordRetClose']";
    	public String Clicking_AllProj_SchdtoRet="Clicking Scheduled to be Retrieved breakouts;xpath~//a[@data-target='#dvScheduled']";
    	public String Closing_AllProj_SchdtoRe="Closing Scheduled to be Retrieved Pop-up;xpath~//*[@id='dvScheduledClose']";
    	public String Clicking_PastDue="Clicking Past Due breakouts;xpath~//a[@data-target='#dvPastDue']";
    	public String Closing_PastDue="Closing Past Due Pop-up;xpath~//*[@id='dvPastDueClose']";
    	public String Clicking_PNP="Clicking PNP breakouts;xpath~//a[@data-target='#dvPNPChart']";
    	public String Closing_PNP="Closing PNP Pop-up;xpath~//*[@id='dvPNPClose']";
    	public String Clicking_NotRecoverable="Clicking Not Recoverable breakouts;xpath~//a[@data-target='#dvNotRecoverable']";
    	public String Closing_NotRecov="Closing Not Recoverable Pop-up;xpath~//*[@id='dvNRClose']";
    	
		}


