package WDPOM;

public class DashboardsByProject {
	public String DrpDashboards="Select Dashboards;LinkText~Dashboards";
	public String DrpDashboards_ByProject="Select By Project;LinkText~By Project";
}
