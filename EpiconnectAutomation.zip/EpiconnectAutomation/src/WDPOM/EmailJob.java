package WDPOM;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailJob {
	public static void main(String args[]) throws ParseException{
		@SuppressWarnings("unused")
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
		String startTime="2018-09-04 04:28:32";
		Date date1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startTime);

		Date date=new Date();
		DateFormat df= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
 

		//us madrid date format to format the date

		df.setTimeZone(TimeZone.getTimeZone("US/Pacific"));

		System.out.println("Date and Time : "+ df.format(date));

		Date date2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(df.format(date));

		System.out.println("Date 2:" +"\t"+date2);

		long diff=(date2.getTime()-date1.getTime())/(60*60*1000);

		System.out.println(diff);

		if(diff > 2){
		System.out.println("Job is running for more than 2 hours");
		System.out.println("Send Email notifications");
		SendEmailNotify();
		}
		}

		private static void SendEmailNotify(){

		String recipient = "moogambiga@episource.com";

		String sender = "moogambiga@episource.com";

		Properties properties=System.getProperties();

		//Setting up mail server

		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
		//Creating session object to get properties
		Session session=Session.getDefaultInstance(properties);

		try
		{
		//Mime Message object
		Message message=new MimeMessage(session);

		//set from field adding senders to from field

		message.setFrom(new InternetAddress(sender));

		//set to field adding recipient's email to from field.

		message.addRecipient(Message.RecipientType.TO , new InternetAddress(recipient));

		//set subject : Subject of the mail

		message.setSubject("Testing");

		//set body of the email

		message.setText("Test Body \n please verify that the job has not completed");

		//send email

		Transport.send(message);
		System.out.println("Mail successfully sent");
		}
		catch (MessagingException mex)
		{
		mex.printStackTrace();
		}
		}
}
