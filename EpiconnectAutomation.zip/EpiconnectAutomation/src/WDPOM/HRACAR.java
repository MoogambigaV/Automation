package WDPOM;

public class HRACAR {
	public String Drp_ClickHRA_menu="Clicking on HRA;Linktext~HRA";
	public String Drp_HRA_selectingSchedandComp_menu="Selecting Scheduled & Performed;Linktext~Scheduled & Performed";
	public String Drp_HRA_selecting_ClientActionRequired_menu="Client Action Required;xpath~//*[@id='acc432']/a";
	public String HRA_selecting_MemberDeceasedpopup="Clicking Member Deceased;xpath~//*[@id='ah-Member-Deceased']";
	public String HRA_selecting_MemberNoLongeronPlan="Clicking Member No Longer on Plan;xpath~//*[@id='ah-Member-Deceased']";
	public String HRA_selecting_MemberLivesoutpopup="Clicking Member Lives Outside Serviceable Area;xpath~//*[@id='ah-Member-Deceased']";
	public String HRA_selecting_Membercurrentlyintreatment="Clicking Member Currently in Treatment;xpath~//*[@id='ah-Member-Deceased']";
	public String HRA_selecting_Memberincarfacil="Clicking Member in Care Facility;xpath~//*[@id='ah-Member-Deceased']";
	public String HRA_selecting_LanguageBarrier="Clicking Language Barrier;xpath~//*[@id='ah-Member-Deceased']";
	public String HRA_selecting_InvalidPhoneNumber="Clicking Invalid Phone Number;xpath~//*[@id='ah-Member-Deceased']";
	public String HRA_selecting_UnVerifPhNumb="Clicking Unverified Phone Number, 5+ Attempts Made;xpath~//*[@id='ah-Member-Deceased']";
	
	//public String GeneratedTime="Generated Time;xpath~//*[@id='lblheading']/div";

}
