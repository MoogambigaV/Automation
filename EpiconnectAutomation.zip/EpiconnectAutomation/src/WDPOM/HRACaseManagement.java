package WDPOM;

public class HRACaseManagement {

	
	  public String ToolsPage_selectingTools_menu="Selecting Tools;Linktext~Tools";
	  public String selectingTools_CaseManagement="Selecting Case Management;Linktext~Case Management";
	  public String Entering_MemberID="Searching Member ID;xpath~//*[@id='txt0']";
	  public String Clicking_On_ExportToExcel="Clicking on Export to Excel;xpath~//*[@id='xlsImage_CaseDetails']";
}
