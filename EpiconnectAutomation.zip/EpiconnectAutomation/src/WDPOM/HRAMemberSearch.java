package WDPOM;

public class HRAMemberSearch {

	public String Drp_ClickHRA_menu="Menu Selection;Linktext~HRA";
	public String Drp_HRA_selectingMemSearch_menu="Menu Selection;Linktext~Member Search";
	public String SearchBtn_MemSearchPage="Member Search Button;xpath~//*[@id='btnsrchicon']";
	public String Entering_ItemId="Entering_ID_Srchicon;xpath~//*[@id='txtMemSearch-0']";
	public String Clicking_On_ExportToExcel="Clicking on Export to Excel;xpath~//*[@id='xlsImage_RDE']";
	//public String Click_Location_ID="Click Location ID_First;xpath~//*[@id='L-00483879']/a";
	}
	//public String GeneratedTime="Generated Time;xpath~//*[@id='lblheading']/div";
//*[@id="txtSearch"]