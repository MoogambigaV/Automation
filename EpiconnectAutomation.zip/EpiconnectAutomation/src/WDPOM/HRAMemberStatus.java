package WDPOM;

public class HRAMemberStatus {
	public String Drp_ClickHRA_menu="Clicked on HRA Member Status;Linktext~HRA";
	public String Clicking_HRA_MemberStatus_PreOutreach="Clicking Pre-Outreach breakouts;xpath~//*[@id='ah-Pre-Outreach']";
	public String Closing_HRA_MemberStatus_PreOutreach="Closing Pre-Outreach Pop-up;xpath~//*[@id='dvPreProductionClose']";
	public String Clicking_HRA_MemberStatus_MemberOutreach="Clicking Member Outreach breakouts;xpath~//*[@id='ah-Member-Outreach']";
	public String Closing_HRA_MemberStatus_MemberOutreach="Closing MemberOutreach Pop-up;xpath~//*[@id='dvPreProductionClose']";
	public String Clicking_HRA_MemberStatus_Scheduled="Clicking Scheduled breakouts;xpath~//*[@id='ah-Scheduled']";
	public String Closing_HRA_MemberStatus_Scheduled="Closing Scheduled Pop-up;xpath~//*[@id='dvPreProductionClose']";
	public String Clicking_HRA_MemberStatus_VisitPerformed="Clicking Visit Performed breakouts;xpath~//*[@id='ah-Visit-Performed']";
	public String Closing_HRA_MemberStatus_VisitPerformed="Closing Visit Performed Pop-up;xpath~//*[@id='dvPreProductionClose']";
	public String Clicking_HRA_MemberStatus_Declined="Clicking Declined breakouts;xpath~//*[@id='ah-Declined']";
	public String Closing_HRA_MemberStatus_Declined="Closing Declined Pop-up;xpath~//*[@id='dvPreProductionClose']";
	public String Clicking_HRA_MemberStatus_ClientActionRequired="Clicking Client Action Required;xpath~//*[@id='ah-Client-Action Required']";
	public String Closing_HRA_MemberStatus_ClientActReq="Closing Client Action Required Pop-up;xpath~//*[@id='dvPreProductionClose']";
}

