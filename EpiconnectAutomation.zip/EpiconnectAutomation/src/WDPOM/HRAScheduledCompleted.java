package WDPOM;

public class HRAScheduledCompleted {
	public String Drp_ClickHRA_menu="Clicking HRA;Linktext~HRA";
	public String Drp_HRA_selectingSchedComp_menu="Selecting Scheduled & Performed;Linktext~Scheduled & Performed";
	public String Drp_VisitPerformed_Selecting_Week_View="Selecting Week View in Visit Performed Section;xpath~//*[@id='selview']";
	public String Drp_VolumeByDeliveryDate_Week_View="Selecting Week View in Volume By Delivery Date Section;xpath~///*[@id='selDelivery']";
	//public String GeneratedTime="Generated Time;xpath~//*[@id='lblheading']/div";
}
