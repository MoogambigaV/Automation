package WDPOM;

public class HRAStatusDetail {
	public String Drp_ClickHRA_menu="Clicking HRA;Linktext~HRA";
	public String Drp_HRA_selectingStatusSummary_menu="Selecting Status Details Page;Linktext~Status Detail";
	//public String GeneratedTime="Generated Time;xpath~//*[@id='lblheading']/div";
}
