package WDPOM;

import WDFrameworkComponents.GenericComponentImplementation;
import WDUtilities.CommonUtil;

public class HomePage 
{
	/**Login Page Objects**/
	public String Txt_Epiconnect_HomePage_Email="User Name;id~UserName";
	public String Txt_Epiconnect_HomePage_Password="Password ;id~Password";
	public String Btn_Epiconnect_HomePage_Login="Login Button;id~LoginButton";
	public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";

	/**Home Page Objects**/
	public String Drp_HomePage_clickBtn="Click Dropdown;xpath~(//button[@type='button'])[4]";	
	public String Drp_HomePage_selectClient;	
	public String Lst_Epiconnect_homepage_clients="Select Client;xpath~//img[@class='img-responsive logo']/following::div/button[2]/following::ul[@class='dropdown-menu dropdown-menuclient']/li";
	//public String Drp_Epiconnect_homepage_Client="";
	public void selectClient(String OR, String ClientName)
	{
		int ClientCount=GenericComponentImplementation.getFindElementsCount(OR);
		for(int count=1;count<=ClientCount;count++)
		{
			System.out.println("Expected :"+GenericComponentImplementation.getText(Lst_Epiconnect_homepage_clients+"["+count+"]/a"));
			System.out.println("Actual :"+ClientName);
			if(GenericComponentImplementation.getText(Lst_Epiconnect_homepage_clients+"["+count+"]"+"/a").equals(ClientName))
			{
				GenericComponentImplementation.clickOn(Lst_Epiconnect_homepage_clients+"["+count+"]"+"/a");
			    break;
			}	
			if(count>=ClientCount)
			{
				CommonUtil.failTest("No Client Name is Found "+ClientName);
			}
		}
	}
	/*public void RetrievalInventory(String RetrievalInventory)
	{
	System.out.println("Expected:"+GenericComponentImplementation.getText("Retrieval Inventory"));
	System.out.println("Actual :"+RetrievalInventory);
	
	}*/
	//public String Drp_HomePage_clickBtn="Click Dropdown;xpath~(//button[@type='button'])[4]";
}
