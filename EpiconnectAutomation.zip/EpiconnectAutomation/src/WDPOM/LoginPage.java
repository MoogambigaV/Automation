package WDPOM;
import WDFrameworkComponents.GenericComponentImplementation;
public class LoginPage
{
	/**Login Page Objects**/	
	public String Txt_LoginPage_UserName="USER NAME ;id~UserName";
	public String Txt_LoginPage_Password="PASSWORD ;id~Password";	   
	public String Btn_LoginPage_Login="LOGIN Button;id~LoginButton";
	/*public String Txt_LoginPage_Homepage="Home Page;xpath~//*[contains(.,'RECORD RETRIEVAL')]";*/
	
	public void Login(String UserName,String Pwd)
	{	   	 
		GenericComponentImplementation.sendKeys(Txt_LoginPage_UserName,UserName);
		GenericComponentImplementation.sendKeys(Txt_LoginPage_Password,Pwd);
		GenericComponentImplementation.clickOn(Btn_LoginPage_Login);
		GenericComponentImplementation.waitTime(2);
		/*GenericComponentImplementation.verifyElementPresent(Txt_LoginPage_Homepage);*/
	}

}
