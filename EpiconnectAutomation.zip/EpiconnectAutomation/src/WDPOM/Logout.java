package WDPOM;

public class Logout {

	public String Click_Button="Select Logout;xpath~/html/body/nav/div/div[1]/div/div/div[2]/div[1]/button[2]";
	public String Click_LogOut="Clicking Logout;Linktext~Log Out";
	
}
