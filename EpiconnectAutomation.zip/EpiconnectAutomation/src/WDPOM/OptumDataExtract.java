package WDPOM;

public class OptumDataExtract {
	 public String Drp_OptumToolsPage_selectingTools_QueryBuildermenu="Menu Selection;Linktext~Tools";
	//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
	public String Lst_Epiconnect_Tools_selectingQueryBuilder="Select Query Builder;Linktext~Data Extract";
	public String selecting_NewQuery_Btn="Click New Query;xpath~//*[@id='btnOptumQuery']";
	public String Typetoadd_Query_Name="Type to add a Query Name;xpath~//*[@id='txtQueryName']";
	public String clickNext="Click Next;xpath~//*[@id='btnQryProNext']";
	public String SelectingAll="Selecting All Projects;xpath~//*[@id='divSelectAllProj']";
	public String AddProjects="Adding Projects;xpath~//*[@id='btnAddProject']";
	public String ClickProjectsNext="Next Projects;xpath~//*[@id='btnProjectNext']";
	public String ClickLaunchQuery="Launch Query;xpath~//*[@id='btnQryFilterLanchQry']";
	
}
