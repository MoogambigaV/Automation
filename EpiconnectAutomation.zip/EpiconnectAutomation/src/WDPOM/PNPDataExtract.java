package WDPOM;

public class PNPDataExtract {
	//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
	//public String Epiconnect_Tools_selectingQueryBuilder="Select PNP Data Extract;Linktext~Data Extract";
	public String selecting_PNP_Data_Extract_Tab="Click PNP Data Extract;xpath~//*[@id='arefPNPExtract']";
	public String selecting_NewQuery_Btn="Click New Query;xpath~//*[@id='btnPNPQuery']";
	public String Typetoadd_Query_Name="Type to add a Query Name;xpath~//*[@id='txtQueryName']";
	public String clickNext="Click Next;xpath~//*[@id='btnQryProNext']";
	public String SelectingAll="Selecting All Projects;xpath~//*[@id='divSelectAllProj']";
	public String AddProjects="Adding Projects;xpath~//*[@id='btnAddProject']";
	public String ClickProjectsNext="Next Projects;xpath~//*[@id='btnProjectNext']";
	public String ClickLaunchQuery="Launch Query;xpath~//*[@id='btnQryFilterLanchQry']";


}
