package WDPOM;

public class PNPManagement {
	public String Drp_Retrieval_selectingRetrieval_Retrievalmenu="Menu Selection;Linktext~Retrieval";
	public String Drp_Retrieval_selectingPnp_Mgmt="Select PNP Management;Linktext~PNP Management";
	public String Click_ExporttoExcel="Click ExporttoExcel from Main Page;xpath~//*[@id='xlsImage_PNPDetails']";
	public String Entering_Location_ID="Enter Location ID;xpath~//*[@id='txtPNPDLoc-0']";
	public String Click_Location_ID="Click Location ID_First;xpath~//*[@id='tblPNPLocations_body']/tr[1]/td[1]/div/a";
	public String Click_LocationTab_Exporttoexcel="Click Export to Excel in Location Tab;xpath~//*[@id='xlsImage_LocationDetails']";
	public String Click_Location_Profile="Click Location Tab;xpath~//*[@id='arefLoc']";
	public String Click_Providers_Tab="Click Providers Tab;xpath~//*[@id='arefProv']";	
	public String Click_Provider_Link="Click Provider Name;xpath~//*[@id='tblProviderInfo_body']/tr[1]/td[1]/div/a";
	public String Close_Provider_Popup_Link="Closing Provider Pop UP Link;xpath~//*[@id='divModalProviderInfo']/div/div/div/div[@id='divClose']";
	public String Click_PNPCharts_Profile="Click Charts Tab;xpath~//*[@id='arefMem']";
	public String Click_PNPAppointment_Tab="Click Appointments Tab;xpath~//*[@id='arefApp']";	
	public String Click_PNPInvoices_Tab="Click Invoices Tab;xpath~//*[@id='arefInv']";
}

//*[@id='arefMem']
