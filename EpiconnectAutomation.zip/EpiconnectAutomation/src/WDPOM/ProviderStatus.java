package WDPOM;

public class ProviderStatus {
	//String Drp_ToolsPage_selectingChartFinder="Menu Selection;xpath~//button[@type='button'][4]";
 	
	public String Drp_Retrieval_selectingRetrieval_menu="Menu Selection;Linktext~Retrieval";
	//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
	public String Lst_Epiconnect_Retrieval_selectingProviderStatus="Select Provider Status;Linktext~Provider Status";
	
}
