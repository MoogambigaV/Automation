package WDPOM;

public class RetProjectSummary {
	public String Drp_Retrieval_selectingRetrieval_menu="Retrieval;Linktext~Retrieval";
	public String Drp_Retrieval_selectingRetrProjSummary_menu="Project Summary;Linktext~Project Summary";
	public String Clicking_RetrProjRetrieved="Clicking Retrieved breakouts;xpath~//a[@data-target='#dvRetrieved']";
	////*[@id="tbodyRetrievalLegend"]/tr[1]/td[1]/div/div/div/p/a
	public String Closing_RetrProj_Retr="Closing Retrieved Pop-up;xpath~//*[@id='dvRecordRetClose']";
	public String Clicking_RetrProj_SchdtoRet="Clicking Scheduled to be Retrieved breakouts;xpath~//a[@data-target='#dvScheduled']";
	public String Closing_RetrProj_SchdtoRe="Closing Scheduled to be Retrieved Pop-up;xpath~//*[@id='dvScheduledClose']";
	public String Clicking_PastDue="Clicking Past Due breakouts;xpath~//a[@data-target='#dvPastDue']";
	public String Closing_PastDue="Closing Past Due Pop-up;xpath~//*[@id='dvPastDueClose']";
	public String Clicking_PNP="Clicking PNP breakouts;xpath~//a[@data-target='#dvPNPChart']";
	public String Closing_PNP="Closing PNP Pop-up;xpath~//*[@id='dvPNPClose']";
	public String Clicking_NotRecoverable="Clicking Not Recoverable breakouts;xpath~//a[@data-target='#dvNotRecoverable']";
	public String Closing_NotRecov="Closing Not Recoverable Pop-up;xpath~//*[@id='dvNRClose']";
	public String Clicking_On_MoreDetails_Link="Clicking More Details link;xpath~//*[@id='ahRetrieval']";
}
