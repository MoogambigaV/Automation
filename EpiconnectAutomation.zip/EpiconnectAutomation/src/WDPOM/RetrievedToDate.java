package WDPOM;

public class RetrievedToDate {
	public String Drp_Retrieval_selectingRetrieval="Selecting Retrieval;Linktext~Retrieval";
	public String Drp_Retrieval_RetrievedToDatemenu="Select Retrieved To Date;Linktext~Retrieved To Date";
}
