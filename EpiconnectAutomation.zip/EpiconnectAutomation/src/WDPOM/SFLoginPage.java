package WDPOM;

import WDFrameworkComponents.GenericComponentImplementation;

public class SFLoginPage {
	public static String Txt_Salesforce_HomePage_Username="Username;id~username";
	public static String Txt_Salesforce_HomePage_Password="Password ;id~password";
	public static String Btn_Salesforce_HomePage_Login="Login Button;id~Login";
	

	/**Home Page Objects**/
	public String Click_ReportsTab="Click Reports;LinkText~Reports";
	public String Click_Epiconnect_RetrievalStatus="Epiconnect Retrieval Status;xpath~//*[@id='00O5A000006cv3a_NAME']/div[2]/a/span)";
		////*[@id="00O5A000006cv3a_NAME"]/div[2]/a/span
	
public static void SFLogin(String username,String password)
{	   	 
	GenericComponentImplementation.sendKeys(Txt_Salesforce_HomePage_Username,username);
	GenericComponentImplementation.sendKeys(Txt_Salesforce_HomePage_Password,password);
	GenericComponentImplementation.clickOn(Btn_Salesforce_HomePage_Login);
	GenericComponentImplementation.waitTime(2);
	/*GenericComponentImplementation.verifyElementPresent(Txt_LoginPage_Homepage);*/
}
}