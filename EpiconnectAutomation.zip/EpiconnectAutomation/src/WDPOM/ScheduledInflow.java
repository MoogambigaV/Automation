package WDPOM;

public class ScheduledInflow {

	public String Drp_Retrieval_selectingRetrieval_menu="Selecting Retrieval;Linktext~Retrieval";
	//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
	public String Lst_Epiconnect_Retrieval_selectingScheduledInflow="Select Scheduled Inflow;Linktext~Scheduled Inflow";
	
	
}
