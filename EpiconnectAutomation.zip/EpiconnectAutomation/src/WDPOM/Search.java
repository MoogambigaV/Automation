package WDPOM;

import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.remote.server.handler.SendKeys;

public class Search {
	public String Drp_Retrieval_selectingRetrieval_Searchmenu="Menu Selection;Linktext~Retrieval";
	public String Drp_Retrieval_selectingSearch="Select Search;Linktext~Search";
	public String Click_LocationID_Searchicon="Click Location ID_Srchicon;xpath~//*[@id='btnsrchicon']";
	public String Entering_PracticeName="Entering_Practice_Name_Srchicon;xpath~//*[@id='TxtLoc-1']";
	public String Click_Location_ID="Click Location ID_First;xpath~//*[@id='L-01091830']/a";
	//public String Click_Location_ID="Click Location ID_First;xpath~//*[@id='L-01091820']/a";
	public String Click_Providers_Tab="Click Providers Tab;xpath~//*[@id='arefProv']";
	public String Click_Provider_Link="Click Provider Name;xpath~//*[@id='0']/a";
	public String Close_SchProvider_Popup_Link="SrchClosing Provider Pop UP Link;xpath~//*[@id='divModalProviderInfo']/div/div/div/div[@id='divClose']";
	public String Click_Charts_Profile="Click Charts Tab;xpath~//*[@id='arefMem']";
	public String Click_Appointment_Tab="Click Appointments Tab;xpath~//*[@id='arefApp']";	
	public String Click_Invoices_Tab="Click Invoices Tab;xpath~//*[@id='arefInv']";
}

//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
//public String Mouse_At_Location_ID="Mouse at Location ID;xpath~//*[@id='txtSearch']";





