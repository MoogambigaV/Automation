package WDPOM;

public class selectingClient {

	 	String Drp_HomePage_selectingClient="Client Selection;xpath~//button[@type='button'][4]";
		//public String Btn_Epiconnect_HomePage_Login_FailedErrormessage="Error Message;xpath~//*[@id='dvlogo']/span";
		
	    //driver.findElement(By.linkText("Optum"));
	 

}
