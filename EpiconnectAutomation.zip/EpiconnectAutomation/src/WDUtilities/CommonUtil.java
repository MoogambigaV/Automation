package WDUtilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import org.testng.Reporter;
import org.testng.Assert;

import WDFrameworkComponents.GenericComponentImplementation;

public class CommonUtil extends LogUtil
{
	public static void passTest(String Message)
	{
		Reporter.log("</font><font color='green'>"+ Message+"</font>");
		setLog("info",Message);		   	 
	}	
	public static void passTest(String Message,String Value)
	{
		Reporter.log("</font><font color='green'>"+ Message+"</font>:"+"<font color='Orange'>'"+Value+"'</font></br>");
		setLog("info",Message+":"+Value);		   	 
	}	
	public static void passTest(String Message,String Value,String Color)
	{
		Reporter.log( "<font color='"+Color+"'>'"+Message+" "+Value+"'</font></br>");
		setLog("info",Message+":"+Value);		   	 
	}
	public static void failTest(String Message)
	{	  
		Reporter.log("</font><font color='red'>"+ Message+"</font>:FAILURE");
		setLog("ERROR",Message);
		GenericComponentImplementation.testFailure=true;
		try {
			Screenshot.takeScreenshot(Screenshot.screenshotCount);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.fail(Message);
	} 
	public static String getDateFormat(String Date, String ExpectedFormat, String ActualFormat)
	{
		String DateMod="";

		SimpleDateFormat originalFormat = new SimpleDateFormat(ActualFormat);
		SimpleDateFormat targetFormat = new SimpleDateFormat(ExpectedFormat);
		Date date;
		try {
			date = originalFormat.parse(Date);
			System.out.println("Old Format :   " + originalFormat.format(date));
			System.out.println("New Format :   " + targetFormat.format(date));
			DateMod=targetFormat.format(date);
			System.out.println("Date Format :" +DateMod);
		} catch (Exception ex) 
		{
			// Handle Exception.
			ex.printStackTrace();
		}
		/* try
		 {
			   // SimpleDateFormat Actual= new SimpleDateFormat(ActualFormat);
			 DateFormat parser = new SimpleDateFormat(ActualFormat);
			 DateFormat formatter = new SimpleDateFormat(ExpectedFormat);    
			 String initialDeliveryDate = Date;
			 System.out.println(parser.parse(initialDeliveryDate));

			 String finalDeliveryDate = formatter.format(parser.parse(initialDeliveryDate));
				//then to re-format:

				//Actual.applyPattern(Expected);
				//DateMod=Actual.format(date).toString();
				System.out.println(finalDeliveryDate);
				//setLog("INFO","Date format has been changed :"+ExpectedFormat+" Date is :"+DateMod);
		 }
		 catch(Exception e)
		 {
				System.out.println("unable to format it "+ExpectedFormat+" Date is :"+DateMod);
		 }*/
		return DateMod;
	}
	public static String getConfigProperty(String keyword)
	{
		Properties properties=new Properties();

		try 
		{	
			properties.load(new FileInputStream(".\\Config\\TestConfiguration.properties"));
		} 
		catch (FileNotFoundException e) 
		{
			WDUtilities.LogUtil.setLog("ERROR","File Not Found Exception thrown while getting value of "+keyword+" from Test Configuration file");
		} catch (IOException e) 
		{
			WDUtilities.LogUtil.setLog("ERROR","IO Exception thrown while getting value of "+keyword+" from Test Configuration file");
		}
		WDUtilities.LogUtil.setLog("INFO","Getting value of "+keyword+" from Test Configuration file : "+properties.getProperty(keyword));
		return properties.getProperty(keyword);		
	} 
	public static void splitOR(String OR)
	{
		
	}
	 public static void removeSpecificFileTypesInFolder(String FolderPath)
	 {
	 File folder = new File(FolderPath);
	 File fList[] = folder.listFiles();
	 // Searchs .lck
	 for (File f : folder.listFiles()) {
	    if (f.getName().endsWith(".js")) {
	        f.delete(); // may fail mysteriously - returns boolean you may want to check
	        System.out.println("Cleaned up");	       
	    }
	    CommonUtil.setLog("INFO", "We have cleaned up .js files");
	 }
	 }
}

