package WDUtilities;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import org.testng.IInvokedMethod;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestClass;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.collections.Lists;
import Driver.TestDriver;
import WDFrameworkComponents.GenericComponentImplementation;
public class CreateCustomHTMLReport
{
	private static PrintWriter m_out;
	private int currentStep=1;
	private int testIndex;
	static int screenshotNo=0;
	private String TestMethodResultsPath="";
	private String TotalTimeDuration;
	private int TotalNoofTestmethods;
	private int No_of_Passed;
	private int No_of_Failed;
	private int No_of_Skipped;
	private static int ReporterFileCount=1;
	@SuppressWarnings("unused")
	private int  m_methodIndex;
	private static ITestResult ITR;
	private static SimpleDateFormat sdfdate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
	private static SimpleDateFormat sdftime = new SimpleDateFormat("HH:mm:ss a");
	public static Date TestDate;
	private static String timeZone = "GMT-7";
	private String LogoName=TestDriver.EpiLogoName;;
	private String testInstanceName="";

	NumberFormat formatter = new DecimalFormat("#,##0.0");
	long time_start = Long.MAX_VALUE;
	long time_end = Long.MIN_VALUE;


	protected void generateMethodSummaryReport(List<ISuite> suites) 
	{
		m_methodIndex = 0;
		testIndex = 1;       
		for (ISuite suite : suites) 
		{
			Map<String, ISuiteResult> r = suite.getResults();
			for (ISuiteResult r2 : r.values())
			{
				ITestContext testContext = r2.getTestContext();
				String testName = testContext.getName();
				resultSummary(suite, testContext.getFailedConfigurations(),testName, "FAIL"," (configuration methods)");
				resultSummary(suite, testContext.getFailedTests(), testName,"FAIL", "");
				resultSummary(suite, testContext.getSkippedConfigurations(),testName, "SkIP"," (configuration methods)");
				resultSummary(suite, testContext.getSkippedTests(), testName,"SkIP", "");
				resultSummary(suite, testContext.getPassedTests(), testName, "PASS", "");
			}      
		}
		m_out.println("</table>");
	}
	private Collection<ITestNGMethod> getMethodSet(IResultMap tests, ISuite suite) 
	{
		List<IInvokedMethod> r = Lists.newArrayList();
		List<IInvokedMethod> invokedMethods = suite.getAllInvokedMethods();
		for (IInvokedMethod im : invokedMethods) {
			if (tests.getAllMethods().contains(im.getTestMethod()))
			{
				r.add(im);
			}
		}
		//Arrays.sort(r.toArray(new IInvokedMethod[r.size()]), new TestSorter()); 
		List<ITestNGMethod> result = Lists.newArrayList();

		// Add all the invoked methods
		for (IInvokedMethod m : r)
		{
			result.add(m.getTestMethod());
		}

		// Add all the methods that weren't invoked (e.g. skipped) that we
		// haven't added yet
		for (ITestNGMethod m : tests.getAllMethods()) {
			if (!result.contains(m)) {
				result.add(m);
			}
		}
		return result;
	}
	@SuppressWarnings("unused")
	private void resultSummary( ISuite suite, IResultMap tests, String testname, String status, String details ) 
	{		
		int NameCount=0;
		String PrevTestMethodName="";
		if(tests.getAllResults().size()>0) 
		{
			for ( ITestNGMethod method : getMethodSet(tests, suite) )
			{				
				m_methodIndex += 1;
				ITestClass testClass = method.getTestClass();
				String className = testClass.getName();
				//Set<ITestResult> resultSet = tests.getResults(method);
				long end = Long.MIN_VALUE;
				long start = Long.MAX_VALUE;
				for (ITestResult testResult : tests.getResults(method))
				{         
					String description = method.getDescription();
					//System.out.println(description);
					testInstanceName= method.getMethodName();	
					//System.out.println(testInstanceName);			

					if (testResult.getEndMillis() > end) 
					{
						end = testResult.getEndMillis();
					}
					if (testResult.getStartMillis() < start)
					{
						start = testResult.getStartMillis();
					}
					if(method.isTest())
					{
						if(NameCount!=method.getCurrentInvocationCount())
						{
							if(NameCount>0)
							{ 
								m_out.println("<td>"+testIndex+"</td><td><a href='TestMethodResults/"+testInstanceName+"_0"+NameCount+".html'>"
										+ testInstanceName+"_0"+NameCount+ "</a>"+"</td>"
										+"<td>" +description +":"+ parseUnixTimeToTimeOfDay(start)+"</td>"
										+"<td class=\"numi\">" + millisecondsToSeconds(end - start) + "</td>" //TODO need to enhance so the time of each method is shown separately
										+"<td>"+(status.equalsIgnoreCase("Pass")?"<font color=green>"+status+"</font>" : "<font color=red>"+status+"</font>")+ "</td></tr>");
								testIndex++;						
								NameCount++;
								PrevTestMethodName=testInstanceName;
							}
							else
							{				
								if(!testInstanceName.equals(PrevTestMethodName))
								{
									m_out.println("<td>"+testIndex+"</td><td><a href='TestMethodResults/"+testInstanceName+".html'>"
											+ testInstanceName+ "</a>"+"</td>"
											+"<td>" +description +":"+ parseUnixTimeToTimeOfDay(start)+"</td>"
											+"<td class=\"numi\">" + millisecondsToSeconds(end - start) + "</td>" //TODO need to enhance so the time of each method is shown separately
											+"<td>"+(status.equalsIgnoreCase("Pass")?"<font color=green>"+status+"</font>" : "<font color=red>"+status+"</font>")+ "</td></tr>");
									testIndex++;
									NameCount++;
									PrevTestMethodName=testInstanceName;
								}	 
							}
						}
						else
						{
							NameCount=0;							
					/*		System.out.println(PrevTestMethodName);
							System.out.println(testInstanceName);*/
							if(!testInstanceName.equals(PrevTestMethodName))
							{
								m_out.println("<td>"+testIndex+"</td><td><a href='TestMethodResults/"+testInstanceName+".html'>"
										+ testInstanceName+ "</a>"+"</td>"
										+"<td>" +description +":"+ parseUnixTimeToTimeOfDay(start)+"</td>"
										+"<td class=\"numi\">" + millisecondsToSeconds(end - start)+ "</td>" //TODO need to enhance so the time of each method is shown separately
										+"<td>"+(status.equalsIgnoreCase("Pass")?"<font color=green>"+status+"</font>" : "<font color=red>"+status+"</font>")+ "</td></tr>");
								testIndex++;
								NameCount++;
							}
						}					
					}
				}
			}      
		}
	}
	private void setHTMLWriter(String HTMLFileName,String Outdir)
	{
		TestMethodResultsPath= Outdir;
		File file=new File(TestMethodResultsPath+"//TestMethodResults");
		if(!file.exists())
		{ 
			file.mkdir();
		}
		TestMethodResultsPath= TestMethodResultsPath+"//TestMethodResults//";
		m_out= createWriter(HTMLFileName,TestMethodResultsPath);
		if(m_out!=null)
		{
			System.out.println("Writer object is initiated "+m_out.toString());
		}
		else
		{
			System.out.println("Writer object is not initiated "+m_out.toString());
		}
		if(ReporterFileCount<=TotalNoofTestmethods)
		{
			ReporterFileCount++;
			System.out.println("Method report "+ReporterFileCount);
			if(ReporterFileCount==TotalNoofTestmethods)
			{
				ReporterFileCount=1;
			}
		}	 
	}
	private void setHTMLWriter(String HTMLFileName)
	{  		 
		try
		{
			System.out.println("File: "+GenericComponentImplementation.outputDirectory);
			File file=new File(GenericComponentImplementation.outputDirectory);
			if(file.canWrite())
			{
				m_out= createWriter(HTMLFileName,GenericComponentImplementation.outputDirectory);
				System.out.println("Can write");
			}
			else
			{
				System.out.println("Cannot write");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	@SuppressWarnings("resource")
	private PrintWriter createWriter(String HTMLFileName,String outdir)
	{	   		
		try
		{
			new PrintWriter(new BufferedWriter(new FileWriter(new File(outdir, HTMLFileName+".html")))).checkError();
			return new PrintWriter(new BufferedWriter(new FileWriter(new File(outdir, HTMLFileName+".html"))));
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	private void startHtml(PrintWriter out)
	{
		out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">");
		out.println("<html xmlns=\"http://www.w3.org/1999/xhtml\">");
		out.println("<head>");
		out.println("<title>EPICONNECT Test Report</title>");
		out.println("</head>");
		out.println("<body>");
	}
	private void endHtml(PrintWriter out)
	{
		out.println("</body></html>");
	}

	public void generateMethodHTMLReport()	  
	{		   		 
		TestListener Listener=new TestListener();
		ITR=Listener.report;
		List<String> output = Reporter.getOutput(ITR);
		setHTMLWriter(ITR.getMethod().getMethodName(),GenericComponentImplementation.outputDirectory);
		startHtml(m_out);
		m_out.print("<img src='../Logo/"+LogoName+"' alt='Logo' height='75'  width='150' align='left'>");
		m_out.println("<font color='Blue'><center><h1>"+ ITR.getMethod()+"</h1></center></font><Br/>");
		for(int i=0;i<output.size();i++)
		{
			m_out.print("<font size=4>"+(currentStep+i)+"."+output.get(i)+"</font>");
		}
		if( GenericComponentImplementation.testFailure==true)
		{			
			embedScreenshotInReport(m_out,ITR.getMethod().toString());
			GenericComponentImplementation.testFailure=false;
		}
		endHtml(m_out);
		m_out.close();		  
	}
	public void generateMethodHTMLReport(String MethodName,List<String> output)	  
	{
		try
		{
			ITR=Reporter.getCurrentTestResult();
			setHTMLWriter(MethodName,GenericComponentImplementation.outputDirectory);
			startHtml(m_out);
			//	System.out.println(MethodName +"HTML Method created");
			m_out.print("<img src='../Logo/"+LogoName+"' alt='Logo' height='75'  width='150' align='left'>");
			m_out.println("<font color='Blue'><center><h1>"+ MethodName+"</h1></center></font><Br/>");
			for(int i=0;i<output.size();i++)
			{
				String Text=output.get(i);
				if(output.get(i).contains(":FAILURE"))
				{
					//m_out.println("<font color='red'><font size=4>"+(currentStep+i)+"."+output.get(i)+"</font>");
					//System.out.println(Text);
					Text=Text.replace("[", "<").replace("]", ">");
					//System.out.println(Text);
					m_out.println((currentStep+i)+"."+Text);
					//System.out.println("<font size=4>"+(currentStep+i)+"."+output.get(i)+"</font></br>");
					embedScreenshot(m_out,GenericComponentImplementation.outputDirectory+"\\ScreenShot\\Failure_"+screenshotNo); 
				}	
				else
				{
					//m_out.println("<font color='green'><font size=4>"+(currentStep+i)+"."+output.get(i)+"</font>");
					if(Text.contains("["))
					{
						//System.out.println(Text);
						Text=Text.replace("[", "<").replace("]", ">");
						//System.out.println(Text);
						m_out.println((currentStep+i)+"."+Text);
						//	System.out.println("<font size=4>"+(currentStep+i)+"."+output.get(i)+"</font></br>");
					}				
					else
					{
						m_out.println((currentStep+i)+"."+output.get(i));
						//	System.out.println("<font size=4>"+(currentStep+i)+"."+output.get(i)+"</font></br>");
					}
				}

			}
			/*	if( GenericComponentImplementation.testFailure==true)
			{
				GenericComponentImplementation.testFailure=false;
				embedScreenshotInReport(m_out,MethodName);
			}*/
			endHtml(m_out);
			m_out.close();	
			m_out.flush();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/*private String getStatusString(int testResultStatus)
   {
		    switch (testResultStatus) 
		    {
		    case 1:
		      return "PASS";
		    case 2:
		      return "FAIL";
		    case 3:
		      return "SKIP";
		    case 4:
		      return "SUCCESS_PERCENTAGE_FAILURE";
		    }
		    return null;
	 }*/
	public void generateReportSummary(String HTMLFileName,String outDir,List<ISuite> suites)
	{
		setHTMLWriter(HTMLFileName);
		startHtml(m_out);
		m_out.print("<img src='./Logo/"+LogoName+"' alt='Logo' height='85'  width='200' align='right'>");
		overviewTable(TotalNoofTestmethods,No_of_Passed,No_of_Failed,No_of_Skipped,TotalTimeDuration);
		m_out.println("<h2><p align='center'>Test results</p></h2>");
		m_out.println("<table border='1' width='75%' class='main-page'><tr><th>S.No</th><th>TestCase Name</th><th>Testcase Description</th><th>Duration</th><th>Status</th></tr></br>");
		generateMethodSummaryReport(suites);
		m_out.println("</table>");
		endHtml(m_out);
		m_out.close();
	}
	public void overviewTable(int totalNooftestcases, int passed,int failed,int skipped ,String Duration)
	{   

		m_out.println("<h2><p align='center'>Overview of Test results</p></h2>");
		m_out.println("<table border='1' width='50%' class='main-page'><tr><th>No. of Testcases</th><th>Passed</th><th>Failed</th><th>Skipped</th><th>Total Duration</th></tr></br>");
		m_out.println("<tr align='center' class='invocation-failed'><td><em>"+totalNooftestcases+"</em></td><td><em>"+passed+"</em></td><td><em>"+failed+"</em></td><td><em>"+ skipped+"</em></td><td><em>"+Duration+"</em></td></tr></table>");
	}

	private static void embedScreenshot(PrintWriter out, String pathAndFile)
	{
		out.println("<font color='orange'> Screenshot repository :- "+pathAndFile+".jpg");
		out.println("<a href='file:///"+pathAndFile+".jpg'> ");
		out.println("<img src='file:///"+pathAndFile+".jpg' height='200' width='200'/></a></font>");
	}	
	public static void embedScreenshotInReport(PrintWriter out,String comment)
	{
		screenshotNo++;
		out.println("<font color='orange'>Screenshot for Verification : <b>"+comment+"</b></font>");
		try 
		{
			Screenshot.takeScreenshot(screenshotNo);
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			CommonUtil.setLog("ERROR",""+e.toString());
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonUtil.setLog("Error",e.toString());
			//Assert.fail();
		}	  		
		embedScreenshot(m_out,GenericComponentImplementation.outputDirectory+"\\ScreenShot\\Failure_"+screenshotNo); 
	}
	public void getOverAllDetails(List<ISuite> suites)
	{
		ITestContext testContext;
		No_of_Passed = 0;
		No_of_Failed = 0;
		No_of_Skipped= 0;
		long Duration=0;
		for (ISuite s : suites) 
		{
			for (ISuiteResult sr : s.getResults().values()) 
			{
				testContext = sr.getTestContext();
				No_of_Passed+= testContext.getPassedTests().size();
				No_of_Failed+= testContext.getFailedTests().size();
				No_of_Skipped+= testContext.getSkippedTests().size();
				TotalNoofTestmethods=(No_of_Passed+ No_of_Failed+No_of_Skipped);
				System.out.println("Total No fo test methods :"+TotalNoofTestmethods);
				time_start = Math.min(testContext.getStartDate().getTime(), time_start);
				time_end = Math.max(testContext.getEndDate().getTime(), time_end);
				Duration= (time_end-time_start);
				long seconds = (Duration / 1000) % 60;
		        long minutes = (Duration/ (1000 * 60)) % 60;
		        long hours = Duration / (1000 * 60 * 60);
		        if(minutes==0&hours==0)                    
		        {
		             TotalTimeDuration=seconds+" Secs";
		        }
		        else  if(hours==0&minutes>0)        
		        {
		            TotalTimeDuration=minutes+" Mins:"+seconds+" Secs";
		        }
		        else      
		        {                    
		              TotalTimeDuration=hours+" Hrs :"+minutes+" Mins:"+seconds+" Secs";
		        }
			}
		}    	    
	}
	protected String parseUnixTimeToDate( long unixSeconds ) {
		Date date = new Date( unixSeconds );
		sdfdate.setTimeZone( TimeZone.getTimeZone( timeZone ) );
		return sdfdate.format( date );
	}

	protected String parseUnixTimeToTimeOfDay( long unixSeconds ) {
		Date date = new Date( unixSeconds );
		sdftime.setTimeZone( TimeZone.getTimeZone( timeZone ) );
		return sdftime.format( date );
	}

 protected String millisecondsToSeconds( long ms ) {
		//return new BigDecimal( ms/1000.00 ).setScale( 2, RoundingMode.HALF_UP );
		long seconds = (ms / 1000) % 60;
        long minutes = (ms / (1000 * 60)) % 60;
        long hours = ms / (1000 * 60 * 60);
        if(minutes==0&hours==0)                    
        {
            return TotalTimeDuration=seconds+" Secs";
        }
        else  if(hours==0&minutes>0)        
        {
            return TotalTimeDuration=minutes+" Mins:"+seconds+" Secs";
        }
        else      
        {                    
            return TotalTimeDuration=hours+" Hrs :"+minutes+" Mins:"+seconds+" Secs";
        }
	}


}
