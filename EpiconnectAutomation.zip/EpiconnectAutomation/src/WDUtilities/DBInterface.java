package WDUtilities;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

public class DBInterface extends DataDriverJXL
{
	public static Connection conn = null;
	public static CallableStatement statement = null;
	static java.sql.Statement stmt = null;
	static ResultSet rset=null;
	public void connectDBServer(String ServerURl,String UserName,String Password) 
	{

		if(ServerURl.equals(null)||UserName.equals(null)||Password.equals(null))
		{
			System.out.println("Invalid DB credentials");
		}
		else
		{
			dbConnect(ServerURl,UserName,Password);
		}
	}
	public int getResultSetofFirstColumn(String Query)
	{	  
		int size=0;

		try
		{			
			CommonUtil.setLog("INFO","PASSED :-Executing the query:"+Query);
			rset= stmt.executeQuery(Query);
			while(rset.next())
			{
				size=Integer.parseInt(rset.getString(1));
			}
			CommonUtil.setLog("INFO","Got the Size/Count :"+ size+" with the above given query" );
			return size;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Unable to fetch the given query "+Query+" " + size+e.toString());		
		}
		return size;
	}
	public  String getResultValueofFirstColumn(String Query)
	{	  
		String Value="";
		try
		{			
			CommonUtil.setLog("INFO","Executing the query successfully Fecthcing Result Set:"+Query);
			rset= stmt.executeQuery(Query);
			while(rset.next())
			{
				Value=rset.getString(1);
				break;
			}
			CommonUtil.setLog("INFO","PASSED :-Got the first column value :"+ Value+" with the above given query" );
			return Value;
		}
		catch(SQLException e)
		{		
			e.printStackTrace();
			Value= "";
			CommonUtil.failTest("Executed the query successfully :"+Query);

		}
		catch(NullPointerException e)
		{	
			CommonUtil.setLog("INFO"," Null:-Executing the query:"+Query);
			System.out.println("Unable to fetch the given query "+Query+" " + Value+e.toString());	

		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","FAILED :-Executing the query:"+Query);
			System.out.println("Unable to fetch the given query "+Query+" " + Value+e.toString());	

		}
		return Value;
	}
	public  String getResultValueofSecondRowFirstColumn(String Query)
	{	  
		String Value="";
		int count=0;
		try
		{			
			CommonUtil.setLog("INFO","PASSED :-Executed the query successfully :"+Query);
			rset= stmt.executeQuery(Query);
			while(rset.next())
			{
				Value=rset.getString(1);
				count++;
				if(count==2)
				{
					break;
				}
			}
			CommonUtil.passTest("Got the first column value :"+ Value+" with the above given query" );
			return Value;
		}
		catch(SQLException e)
		{			
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Executed the query successfully :"+Query);

			Value= "";

		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","FAILED :-Executing the query:"+Query);
			System.out.println("Unable to fetch the given query "+Query+" " + Value+e.toString());	

		}
		return Value;
	}
	public int getTotalNoOfQuery_DB(String Query)
	{	  
		int size=0;
		try
		{			
			if(Query.contains("\n"))
			{
				Query.replaceAll("\n", "");
			}
			CommonUtil.setLog("INFO","PASSED :-Executing the query :"+Query);
			rset= stmt.executeQuery(Query);
			while(rset.next())
			{
				//size=rset.getFetchSize();

				size=rset.getRow();
				System.out.println(size);
			}
			CommonUtil.setLog("INFO","Fetched the given query Total count is:" + size);
			return size;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Unable to fetch the given query "+Query+" Total count is:" + size+e.toString());		
		}
		return size;
	}
	public int  t()
	{
		return 0;

	}
	public void dbConnect(String db_connect_string,String db_userid, String db_password)
	{
		try
		{
			Class.forName("net.sourceforge.jtds.jdbc.Driver");
			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			CommonUtil.passTest("Successfully connected "+db_connect_string+" User Name : "+ db_userid+" Password : "+db_password);
			CommonUtil.setLog("INFO","PASSED :-connected");
			stmt = conn.createStatement();
			CommonUtil.setLog("INFO","PASSED :-Statement created succesfully");

		}
		catch (Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Unable to access teh DB"+e.toString());
		}
	}

	public void executeQuery(String Query)
	{  
		try
		{			
			CommonUtil.setLog("INFO","PASSED :-Executing the query:"+Query);
			rset= stmt.executeQuery(Query);
			CommonUtil.passTest("Executed the given query & the Resultset :" + Query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Unable to fetch the given query "+Query+" " +e.toString());		
		}
	}
	public void executeUpdate(String Query)
	{	 
		try
		{			
			CommonUtil.setLog("INFO","PASSED :-Executing the query:"+Query);
			stmt.executeUpdate(Query);
			CommonUtil.passTest("UPDATE QUERY :-" + Query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Unable to Update the given query "+Query+" " +e.toString());		
		}

	}
	public String[] getResultsetinArrayofFirstRow(String Query)
	{	 
		ArrayList<String> ResultColValue = new ArrayList<String>(); 
		try
		{			
			CommonUtil.setLog("INFO","PASSED :-Executing the query:"+Query);
			rset= stmt.executeQuery(Query);
			CommonUtil.setLog("INFO","Got the Resultset with the given query Resultset :" + Query);
			int columnCount = rset.getMetaData().getColumnCount();
			rset.next();
			for (int colNo = 0 ; colNo <columnCount ; colNo++)
			{	 
				ResultColValue.add( rset.getString(colNo + 1) );
			}				 
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Unable to fetch the given query "+Query+" " +e.toString());		
		}
		return (String[]) ResultColValue.toArray(new String[ResultColValue.size()]);
	}


	public java.util.Date addDays(Date date, int days)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); //minus number would decrement the days
		return cal.getTime();
	}

	public void execSP(String SPName)
	{		
		try 
		{
			CommonUtil.setLog("INFO","PASSED :-Executing the query:"+SPName);
			statement = conn.prepareCall("{call "+SPName+"}");
			//rset= stmt.executeUpdate(SPName);
			statement.executeUpdate(); 
			CommonUtil.passTest("Executed :-"+SPName+" Successfully!");
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Executed :-"+SPName+" It's an unSuccessful Execution "+e.toString());
		}

	}
	public String execSPwithReturn(String SPName)
	{		
		String Date="";
		try 
		{
			CommonUtil.setLog("INFO","PASSED :-Executing the query:"+SPName);
			statement = conn.prepareCall("{? = call "+SPName+"}");
			//rset= stmt.executeUpdate(SPName);
			// statement.setString(1, SPName);
			statement.registerOutParameter(1, java.sql.Types.OTHER);
			rset =statement.executeQuery();
			int columnCount = rset.getMetaData().getColumnCount();
			System.out.println(columnCount);
			rset.next();
			Date=rset.getString(1);
			System.out.println(rset.getString(1));
			return Date;

			//	CommonUtil.passTest("Executed :-"+SPName+" Successfully!");


		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonUtil.setLog("ERROR","Executed :-"+SPName+" It's an unSuccessful Execution "+e.toString());
		}
		return Date;

	}
}
