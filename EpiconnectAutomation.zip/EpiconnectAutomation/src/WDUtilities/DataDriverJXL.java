package WDUtilities;
import java.io.File;
import java.io.IOException;

import Driver.TestDriver;
import WDFrameworkComponents.GenericComponentImplementation;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
////////////////////////////////////////////////////////////////////////////////
//Class Name     :DataDriver 
//Purpose    	 :To write the reusable function for Excel sheet (Read,Write..!)
//extends        :null
//Created by     :Tamilarasan
/////////////////////////////////////////////////////////////////////////////////

public class DataDriverJXL extends CommonUtil
{

	private static int currentExcelSheetNo=1;
	private static File excelDirectory;
	private static Workbook existingworkbookcopy;
	private static WritableWorkbook workbookcopy;
	private static WritableSheet writablesheetcopy;
	private static Sheet existingsheet;
	private static Cell existingCellcopy ;
	private static int TotalDataRowCount=0;
	private static int TotalDataColCount=0;
	private static int currentColumnNo;
	private static int currentRowNo;
	public static String TestConfigExcelDirectory=".//DataStream//Testconfig.xls"; 
	public static String TestDataExcelDirectory=".//DataStream//TestData.xls"; 
	public static String propertiesFilepath="";
	private static int testDataRowcount=1;
	private static int testDataColNo=1;


	public String getExcelDirectory()
	{
		return excelDirectory.toString();
	}

	private static void setCurrentExcelSheet(String ExcelPath,int sheetNo)
	{
		excelDirectory=new File(ExcelPath);
		try
		{
			if(excelDirectory.exists())
			{
				existingsheet=existingworkbookcopy.getSheet(sheetNo-1);
			}
			else
			{
				setLog("INFO","No Excelsheet on specified path"+ existingsheet.getName());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.failTest("Excel Write :"+e.toString());
		}
	}
	private static void setCurrentExcelSheet(String ExcelPath,String sheetName)
	{
		excelDirectory=new File(ExcelPath);
		try
		{
			if(excelDirectory.exists())
			{
				existingsheet=existingworkbookcopy.getSheet(sheetName);
			}
			else
			{
				setLog("INFO","No Excelsheet on specified path"+ existingsheet.getName());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			CommonUtil.failTest("Excel Write :"+e.toString());
		}
	}

	public String getCurrentExcelSheet()
	{
		return  existingsheet.getName();
	}

	public static void availExcelSheet(String ExcelPath,int sheetNo) throws IOException
	{
		excelDirectory=new File( ExcelPath);
		if(excelDirectory.exists())
		{
			try 
			{
				existingworkbookcopy=Workbook.getWorkbook(excelDirectory);
				if(existingworkbookcopy.isProtected())
				{				


				}
				else
				{					
					setCurrentExcelSheet(ExcelPath ,sheetNo);
					setLog("INFO","Successfully ready to avail the excelsheet  :"+ existingsheet.getName());
				}
			} 
			/*		catch (PasswordException e) 
			{
				// TODO Auto-generated catch block
				//e.printStackTrace();
				((WritableSheet) existingworkbookcopy).setProtected(false);
				WritableWorkbook copy = Workbook.createWorkbook(new File(".//DataStream//Testconfig.xls"), existingworkbookcopy);
				WritableSheet[] sheets = copy.getSheets();

				for (WritableSheet sheet : sheets){
				    sheet.getSettings().setProtected(false);
				}
			}*/
			catch (BiffException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			 
		}  			 
		else				
		{
			setLog("Error","File or File path is not exist");
		}
		if(existingworkbookcopy.getNumberOfSheets()>=currentExcelSheetNo)
		{
			getDataTotalColCount();
			getDataTotalRowCount();
		}
	}
	public static Workbook availExcelSheet(String ExcelPath,String sheetName) throws IOException
	{
		excelDirectory=new File(ExcelPath);
		System.out.println("File path "+excelDirectory.getAbsolutePath());
		if(excelDirectory.exists())
		{
			try 
			{
				existingworkbookcopy=Workbook.getWorkbook(excelDirectory);
				System.out.println("No of sheets :"+existingworkbookcopy.getNumberOfSheets());
				System.out.println("Current sheet Name :"+existingworkbookcopy.getSheet(sheetName));
				setCurrentExcelSheet(ExcelPath ,sheetName);
				setLog("INFO","Successfully ready to avail the excelsheet  :"+ existingsheet.getName());
			} 
			catch (BiffException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			 
		}  			 
		else				
		{
			setLog("Error","File or File path is not exist");
		}
		if(existingworkbookcopy.getNumberOfSheets()>=currentExcelSheetNo)
		{
			getDataTotalColCount();
			getDataTotalRowCount();
		}
		return existingworkbookcopy;
	}
	public static Workbook availWritableExcelSheet(String ExcelPath,String sheetName) throws IOException
	{
		excelDirectory=new File(ExcelPath);
		System.out.println("File path"+excelDirectory.getAbsolutePath());
		
			try 
			{
				existingworkbookcopy=Workbook.getWorkbook(excelDirectory);
				workbookcopy=Workbook.createWorkbook(excelDirectory, existingworkbookcopy);
				writablesheetcopy= workbookcopy.getSheet(sheetName);
				setLog("INFO","Excelsheet on specified path :"+ writablesheetcopy.getName());			
			} 
			catch (BiffException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 	
		if(existingworkbookcopy.getNumberOfSheets()>=currentExcelSheetNo)
		{
			getDataTotalColCountWritableSheet();
			getDataTotalRowCountWritableSheet();
		}
		return existingworkbookcopy;
	}
	protected static String getData(int row, int col) 
	{		
		setLog("INFO","Fecthing from Row :"+row+" column :"+col);
		existingCellcopy = existingsheet.getCell(col - 1, row - 1);
		setLog("INFO","Excelsheet got the value  :"+existingCellcopy.getContents());
		if (existingCellcopy.getContents().equalsIgnoreCase("")) 
		{
			System.out.println("No data to display in RowNo "+row+"in  ColumnNo "+col);	
		}
		return existingCellcopy.getContents();
	}

	protected static String getDataWritableSheet(int row, int col) 
	{		
		System.out.println("Fecthing from Row :"+row+" column :"+col);
		setLog("INFO","Fecthing from Row :"+row+" column :"+col);
		existingCellcopy = writablesheetcopy.getCell(col - 1, row - 1);
		setLog("INFO","Excelsheet got the value  :"+existingCellcopy.getContents());
		if (existingCellcopy.getContents().equalsIgnoreCase("")) 
		{
			System.out.println("No data to display in RowNo "+row+"in  ColumnNo "+col);	
		}
		return existingCellcopy.getContents();
	}
	public static void putData(String path,int row, int col,String replacewith) throws RowsExceededException, WriteException, IOException, BiffException 
	{
		excelDirectory=new File(path);
		existingworkbookcopy=Workbook.getWorkbook(excelDirectory);
		setLog("INFO","Successfully read the Workbook..!");
		workbookcopy=Workbook.createWorkbook(excelDirectory, existingworkbookcopy);
		setLog("INFO","Successfully got into createWorkbook..!");
		writablesheetcopy=workbookcopy.getSheet(0);
		setLog("INFO","CurrentExcelsheet Name  :"+writablesheetcopy.getName());
		writablesheetcopy.addCell(new Label(row-1,col-1,replacewith));
		workbookcopy.write();
		setLog("INFO","Successfully wrote the value..!");
		setLog("INFO","Edited Data from Excelsheet :"+writablesheetcopy.getCell(row-1,col-1).getContents());
		workbookcopy.close();
		existingworkbookcopy.close();
		setLog("INFO","Successfully object connection closed..!");
	}
	public static void putTestData(String Data,String replacewith) throws RowsExceededException, WriteException, IOException, BiffException
    {
        String Expected="";
        Expected=getTestConfig("Environment");
        System.out.println("Expected Environment :"+Expected);
 
        try
        {
            if(Expected.equalsIgnoreCase("QA"))
            {
                availWritableExcelSheet(TestDataExcelDirectory,"QA");
            }
            else if(Expected.equalsIgnoreCase("Dev"))
            {
                availWritableExcelSheet(TestDataExcelDirectory,"Dev");
            }
            else if(Expected.equalsIgnoreCase("PROD"))
            {
                availWritableExcelSheet(TestDataExcelDirectory,"PROD");
            }      
            else
            {
                //setLog("ERROR","Sheet Name is invalid"+Expected);
                failTest("Sheet Name is invalid"+Expected);

            }
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        try
        {
            currentColumnNo=testDataColNo;
            System.out.println("EDPS_TestScripts.currentMethodName"+ GenericComponentImplementation.currentMethodName);
            currentRowNo=getRowNumberWritableSheet(currentColumnNo, GenericComponentImplementation.currentMethodName);
            currentColumnNo=getColumnNumberWritableSheet(currentRowNo, Data);
            if(currentColumnNo==0)
            {
                CommonUtil.failTest(Data+" No keywords found in Test data");
            }
            System.out.println("Data Value retreived:"+getData(currentRowNo+1, currentColumnNo));
            getData(currentRowNo+1,currentColumnNo);
        }

        catch (Exception e)
        {
            // TODO: handle exception

            System.out.println("No data Value retreived:"+Data);

        }        

        writablesheetcopy.addCell(new Label(currentColumnNo-1,currentRowNo,replacewith));
        workbookcopy.write();
        setLog("INFO","Successfully wrote the value..!");
        setLog("INFO","Edited Data from Excelsheet :"+writablesheetcopy.getCell(currentColumnNo-1,currentRowNo).getContents());
        workbookcopy.close();
        existingworkbookcopy.close();
        setLog("INFO","Successfully object connection closed..!");

    }
	public static int getColumnNumber(int rownumber,String keyword)
	{
		int ColSize=0;
		String actual="";
		String expected="";
		try
		{
			try
			{
				ColSize =existingsheet.getColumns();
				System.out.println("Size Columun Value:"+ColSize);
				for(int col=1;col<=ColSize;col++)
				{
					/*	System.out.println("Row:"+row);
					System.out.println("col:"+testDataColNo);*/
					actual=getData(rownumber,col).trim();
					expected=keyword.trim();
					System.out.println("Actual:"+actual);
					System.out.println("Expected:"+expected);
					if(actual.equalsIgnoreCase(expected))
					{					 		
						System.out.println(keyword +" : Keyword in the Column Value:"+col);
						return col;
					}	
					if(col>=ColSize)
					{
						System.out.println("No keywords found:"+keyword);
						CommonUtil.failTest("Please ensure that "+keyword+" Keyword is in Testdata sheet : row No :"+rownumber);
					}
				}
			} 
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				CommonUtil.failTest("Please ensure that "+keyword+" Keyword is in Testdata sheet : row No :"+rownumber+"Row No data Value:"+keyword+e.toString());
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("No data Value:"+keyword);
			CommonUtil.failTest("Please ensure that "+keyword+" Keyword is in Testdata sheet : row No :"+rownumber+"Row No data Value:"+keyword+e.toString());

		}
		return 0;

	}
	public static int getColumnNumberWritableSheet(int rownumber,String keyword)
	{
		int ColSize=0;
		String actual="";
		String expected="";
		try
		{
			try
			{
				ColSize =writablesheetcopy.getColumns();
				System.out.println("Size Columun Value:"+ColSize);
				for(int col=1;col<=ColSize;col++)
				{
					/*	System.out.println("Row:"+row);
					System.out.println("col:"+testDataColNo);*/
					actual=getDataWritableSheet(rownumber,col).trim();
					expected=keyword.trim();
					System.out.println("Actual:"+actual);
					System.out.println("Expected:"+expected);
					if(actual.equalsIgnoreCase(expected))
					{					 		
						System.out.println(keyword +" : Keyword in the Column Value:"+col);
						return col;
					}	
					if(col>=ColSize)
					{
						System.out.println("No keywords found:"+keyword);
						CommonUtil.failTest("Pleasure ensure that "+keyword+" Keyword is in Testdata sheet : row No :"+rownumber);
					}
				}
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println("Row No data Value:"+keyword+e.toString());
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("No data Value:"+keyword);
		}
		return 0;

	}
	public static  int getRowNumber1(int testDataColNo, String keyword)
	{

		boolean Flag=true;
		int temp=0;
		try
		{
			while(Flag)
			{
				temp++;
				if(getData(temp,testDataColNo).trim().equalsIgnoreCase(keyword.trim()))
				{
					Flag=false;			
					System.out.println("Row Value:"+temp);
					return temp;
				}			
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Row No data Value:"+keyword+e.toString());
		}
		return 0;

	}
	public static  int getRowNumber(int testDataColNo, String keyword)
	{	 
		int RowSize=0;
		String actual="";
		String expected="";
		try
		{
			RowSize=existingsheet.getRows();
			System.out.println("Size Row Value:"+RowSize);
			for(int row=1;row<=RowSize;row++)
			{
				actual=getData(row,testDataColNo).trim();
				expected=keyword.trim();
				System.out.println("Actual:"+actual);
				System.out.println("Expected:"+expected);
				if(actual.equalsIgnoreCase(expected))
				{					 		
					CommonUtil.setLog("INFO",keyword+" keyword is in the Row Value of: "+row);
					return row;
				}	
				if(row>=RowSize)
				{
					CommonUtil.failTest("No keywords found:"+keyword);
				}
			}
		}
		catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			CommonUtil.failTest("Row No data Value:"+keyword+e.toString());
		}
		catch (Exception e) {
			// TODO: handle exception
			CommonUtil.failTest("Row No data Value:"+keyword+e.toString());
		}
		return 0;

	}
	public static  int getRowNumberWritableSheet(int testDataColNo, String keyword)
	{	 
		int RowSize=0;
		String actual="";
		String expected="";
		try
		{
			RowSize=writablesheetcopy.getRows();
			System.out.println("Size Row Value:"+RowSize);
			for(int row=1;row<=RowSize;row++)
			{
				/*System.out.println("Row:"+row);
				System.out.println("col:"+testDataColNo);*/
				actual=getDataWritableSheet(row,testDataColNo).trim();
				expected=keyword.trim();
				System.out.println("Actual:"+actual);
				System.out.println("Expected:"+expected);
				if(actual.equalsIgnoreCase(expected))
				{					 		
					System.out.println(keyword+" keyword is in the Row Value of: "+row);
					return row;
				}	
				if(row>RowSize)
				{
					System.out.println("No keywords found:"+keyword);
				}
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("Row No data Value:"+keyword+e.toString());
		}
		return 0;

	}

	public static String retrieveTestData(String Data,int sheetNo)
	{
		try {
			closeExcelSheet();
			availExcelSheet(TestDataExcelDirectory,sheetNo);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try 
		{
			currentRowNo=testDataRowcount;  
			currentColumnNo=getColumnNumber(currentRowNo, Data);
			System.out.println("Data Value retreived:"+getData(currentRowNo+1, currentColumnNo));
			return getData(currentRowNo+1,currentColumnNo);
		}

		catch (Exception e) 
		{
			// TODO: handle exception

			System.out.println("No data Value retreived:"+Data);

		}
		closeExcelSheet();
		return null;

	}
	public static String getTestData(String Data)
	{	  
		
		try 
		{
			availExcelSheet(TestDataExcelDirectory,TestDriver.SHEETNAME);
			currentColumnNo=testDataColNo;
			currentRowNo=getRowNumber(currentColumnNo, GenericComponentImplementation.currentMethodName); 
			currentColumnNo=getColumnNumber(currentRowNo, Data);
			if(currentColumnNo==0)
			{
				CommonUtil.failTest(Data+" No keywords found in Test data");
			}
					return getData(currentRowNo+1,currentColumnNo);
		}

		catch (Exception e) 
		{			// TODO: handle exception
			System.out.println("No data Value retreived:"+Data);
		}
		closeExcelSheet();
		return null;

	}

	public static String getTestData(String Data,String currentMethodName)
	{
		String Expected="";
		Expected=getTestConfig("Environment");
		System.out.println("Expected Environment :"+Expected);
		try 
		{
			currentColumnNo=testDataColNo;
			System.out.println("EDPS_TestScripts.currentMethodName"+ currentMethodName);
			currentRowNo=getRowNumber(currentColumnNo,currentMethodName); 
			currentColumnNo=getColumnNumber(currentRowNo, Data);
			if(currentColumnNo==0|currentRowNo==0)
			{
				CommonUtil.failTest(Data+" No keywords found in Test data");
			}
			System.out.println("Data Value retreived:"+getData(currentRowNo+1, currentColumnNo));
			//return getData(currentRowNo+1,currentColumnNo);
			/*
			currentRowNo=testDataRowcount;  
			currentColumnNo=getColumnNumber(currentRowNo, Data);*/
			System.out.println("Data Value retreived:"+getData(currentRowNo+1, currentColumnNo));
			return getData(currentRowNo+1,currentColumnNo);
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("No data Value retreived:"+Data);
			CommonUtil.failTest(Data+" No keywords found in Test data");

		}
		closeExcelSheet();
		return null;

	}
	public static String getTestConfig(String keyword)
	{
		try {
			availExcelSheet(TestConfigExcelDirectory,1);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try 
		{		
			currentColumnNo=testDataColNo;
			currentRowNo=getRowNumber(currentColumnNo, keyword); 
			return getData(currentRowNo,currentColumnNo+1); 
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			System.out.println("No data Value retreived:"+keyword);
		}
		//	closeExcelSheet();
		if(getData(currentRowNo,currentColumnNo+1).equals(null)||getData(currentRowNo,currentColumnNo+1).equals(""))
		{
			failTest("No data Value retreived:"+keyword);
		}
		return null;
	}
	private static int getDataTotalRowCount()
	{

		boolean Flag=true;
		int temp=0;
		try
		{
			while(Flag)
			{
				temp++;
				if(getData(temp,1).length()==0)
				{
					Flag=false;			
					System.out.println("Value:"+temp);
					TotalDataRowCount =temp-1;
					return TotalDataRowCount;
				}			

			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("No row data Value to count");
		}
		return 0;

	}
	////////////////////////////////////////////////////////////////////////////////
	//Function Name  :dataColCount()
	//Purpose    	 :To get the total number of column which contains data
	//Parameters  	 :null
	//Return Value   :Void
	//Created by     :Tamilarasan
	//Created on     :Oct 21st 2013
	/////////////////////////////////////////////////////////////////////////////////
	protected static int getDataTotalColCount()
	{

		boolean Flag=true;
		int temp=0;
		try
		{
			while(Flag)
			{
				temp++;
				if(getData(1,temp).length()==0)
				{
					Flag=false;			
					System.out.println("Value:"+temp);
					TotalDataColCount=temp-1;
					return TotalDataColCount;
				}			

			}
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			System.out.println("No data Value:");
		}
		return 0;

	}
	private static int getDataTotalRowCountWritableSheet()
	{

		boolean Flag=true;
		int temp=0;
		try
		{
			while(Flag)
			{
				temp++;
				if(getData(temp,1).length()==0)
				{
					Flag=false;			
					System.out.println("Value:"+temp);
					TotalDataRowCount =temp-1;
					return TotalDataRowCount;
				}			

			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("No row data Value to count");
		}
		return 0;

	}
	////////////////////////////////////////////////////////////////////////////////
	//Function Name  :dataColCount()
	//Purpose    	 :To get the total number of column which contains data
	//Parameters  	 :null
	//Return Value   :Void
	//Created by     :Tamilarasan
	//Created on     :Oct 21st 2013
	/////////////////////////////////////////////////////////////////////////////////
	protected static int getDataTotalColCountWritableSheet()
	{

		boolean Flag=true;
		int temp=0;
		try
		{
			while(Flag)
			{
				temp++;
				if(getData(1,temp).length()==0)
				{
					Flag=false;			
					System.out.println("Value:"+temp);
					TotalDataColCount=temp-1;
					return TotalDataColCount;
				}			

			}
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			System.out.println("No data Value:");
		}
		return 0;

	}
	public static  void closeExcelSheet()
	{

		currentExcelSheetNo = 0;
		existingworkbookcopy.close();
		excelDirectory = null;
		setLog("INFO","Successfully closed the excel sheet connections");
	}






}
