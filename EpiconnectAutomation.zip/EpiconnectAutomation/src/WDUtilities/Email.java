package WDUtilities;

import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import WDFrameworkComponents.GenericComponentImplementation;
public class Email 
{
	public static void SendEmail(String FilePath,String RecipientsAddresses) {    

		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
		// Get a Properties object
		Properties props = System.getProperties();
		props.setProperty("mail.smtp.host", "smtp.gmail.com");
		props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
		props.setProperty("mail.smtp.socketFactory.fallback", "false");
		props.setProperty("mail.smtp.port", "465");
		props.put("mail.smtp.ssl.enable", "true");
		props.setProperty("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.auth", "true");

		props.put("mail.debug", "false");
		props.put("mail.store.protocol", "pop3");
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.starttls.enable", "true");
		final String username = "moogambiga@episource.com";//
		final String password = "Magnetic@88";

		try{
			Session session = Session.getDefaultInstance(props,new Authenticator()
			{protected PasswordAuthentication getPasswordAuthentication() 
			{
				return new PasswordAuthentication(username, password);
			}});

			// -- Create a new message --
			Message msg = new MimeMessage(session);

			// -- Set the FROM and TO fields --
			msg.setFrom(new InternetAddress(username));
			if(RecipientsAddresses.contains(",")|RecipientsAddresses.contains(";"))
			{
			msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(RecipientsAddresses,false));
			}
			else
			{
			msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(RecipientsAddresses));
			}
			msg.setSubject("Automated Test Report :"+DataDriverJXL.getTestConfig("TestData_SheetName")+" - "+LogUtil.getCurrentTimeStamp("dd/MM/yyyy_HH:mm:ss"));//
			msg.setSentDate(new Date());

			// Create the message part 
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setText("Hi, \nPlease find the attached automated test Report of Epiconnect application. \nThanks,\nMoogambiga V \n\n\n Note: The gmail doesn't allow to attach the certain files like zip due to security reasons.Please rename the file from zip1 to zip. \n\n\n\n\n\n This is an auto generated E-Mail with JAVAMAIL API");
			// Create a multipart message
			Multipart multipart = new MimeMultipart();

			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			messageBodyPart = new MimeBodyPart();
			DataSource source = new FileDataSource(FilePath);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(GenericComponentImplementation.ResultFolderName);
			multipart.addBodyPart(messageBodyPart);

			// Send the complete message parts
			msg.setContent(multipart);
			Transport.send(msg);
			System.out.println("Message has sent.");
		}
		catch (MessagingException e)
		{ 
			//e.printStackTrace();
			System.out.println("Error exception: " + e.toString());
		}

	} 

}
