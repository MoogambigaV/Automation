package WDUtilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import WDFrameworkComponents.GenericComponentImplementation;

public class LogUtil extends TestListener
{
	private String outputFileName="";
	private static String currentTimeStamp="";
	private String currentTimeStampFormat="yyyyMMdd_HH_mm_ss";
	private static Logger logger;
	public static String projectAbsolutepath="";

	public  String getOutputDirectory()
	{
		return  GenericComponentImplementation.outputDirectory;
	}
	public  String getOutputFileName()
	{
		try 
		{
			this.outputFileName= new File(".").getCanonicalPath()+ "\\TestReports";

		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return   this.outputFileName;

	}

	public static String getCurrentTimeStamp(String timeStampFormat)
	{

		Date date=new Date();
		currentTimeStamp=new SimpleDateFormat(timeStampFormat).format(date).toString();
		return  currentTimeStamp;

	}
	public void setOutputDirectory(String OutputDirectory)
	{

		try 
		{
			projectAbsolutepath=new File(".").getCanonicalPath();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		GenericComponentImplementation.ResultFolderName="Result_"+getCurrentTimeStamp(currentTimeStampFormat);
		GenericComponentImplementation.outputDirectory =projectAbsolutepath+OutputDirectory+"\\"+GenericComponentImplementation.ResultFolderName;
		new File(GenericComponentImplementation.outputDirectory ).mkdir();
		System.out.println(GenericComponentImplementation.outputDirectory);
	}

	public void createLogFile() 
	{
		String myStr;
		Properties props = new Properties();
		String propsFileName = "./Config/log4j.properties";
		try 
		{
			FileInputStream configStream = new FileInputStream(propsFileName);
			props.load(configStream);
			myStr=GenericComponentImplementation.outputDirectory+"//LogFile.txt";
			props.setProperty("log4j.appender.FA.File",myStr);
			FileOutputStream output = new FileOutputStream(propsFileName);
			props.store(output, "Output Directory updated : "+GenericComponentImplementation.outputDirectory);
			output.close();
			configStream.close();
			PropertyConfigurator.configure(propsFileName);
			logger=Logger.getLogger(myStr);
			setLog("INFO","Startup activites...");
			setLog("INFO", "Test Output Directory creation successful :"+GenericComponentImplementation.outputDirectory);
			setLog("INFO", "Log File creation successful : LogFile.log");
		} 
		catch (IOException ex) 
		{
			System.out.println("There was an error creating the log file");
		}
	}
	public static void setLog(String Type,String message)
	{
		try
		{
			if(Type.equalsIgnoreCase("INFO"))
			{
				logger.info(message);
			}
			else if(Type.equalsIgnoreCase("ERROR"))
			{
				logger.error(message);
			}    	 
			else
			{
				logger.error("Invalid Type logger");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
