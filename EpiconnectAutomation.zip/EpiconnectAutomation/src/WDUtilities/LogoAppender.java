package WDUtilities;
import java.io.File;
import org.apache.commons.io.FileUtils;

import Driver.TestDriver;
import WDFrameworkComponents.GenericComponentImplementation;

public class LogoAppender extends LogUtil
{
	public  void logoAppender()
	{
	  try
	  {
		new File(GenericComponentImplementation.outputDirectory+"//Logo").mkdir();
		FileUtils.copyFile(new File(".//Logo//"+TestDriver.EpiLogoName), new File(GenericComponentImplementation.outputDirectory+"//Logo//"+TestDriver.EpiLogoName));
	   
	  }
	  catch (Exception e) {
		// TODO: handle exception
	}
 }
}
