package WDUtilities;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;
import WDFrameworkComponents.GenericComponentImplementation;

public class Screenshot extends LogoAppender
{
	public static int screenshotCount=0;
	public static  void  takeScreenshot(int countNo) throws IOException
	{
		try
		{
			RemoteWebDriver augmentedDriver =(RemoteWebDriver)GenericComponentImplementation.getDriver();
			File screenshot = ((TakesScreenshot)augmentedDriver).getScreenshotAs(OutputType.FILE);
			new File(GenericComponentImplementation.outputDirectory+"//ScreenShot").mkdir();
			FileUtils.copyFile(screenshot, new File(GenericComponentImplementation.outputDirectory+"//ScreenShot//Failure_"+countNo+".jpg"));

		}

		catch (Exception e) {
			// TODO: handle exception
			File screenshot = ((TakesScreenshot)GenericComponentImplementation.getDriver()).getScreenshotAs(OutputType.FILE);
			new File(GenericComponentImplementation.outputDirectory+"//ScreenShot").mkdir();
			FileUtils.copyFile(screenshot, new File(GenericComponentImplementation.outputDirectory+"//ScreenShot//Failure_"+countNo+".jpg"));

		}
	}

}
