package WDUtilities;
import java.util.List;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter; 
import org.testng.xml.XmlSuite;
import WDFrameworkComponents.GenericComponentImplementation;
public class TestListener extends TestListenerAdapter implements IReporter
{
	CreateCustomHTMLReport ReportMethod=new CreateCustomHTMLReport();;	
	static int TestCount=0;
	ITestResult report=Reporter.getCurrentTestResult();
	public void onStart(ISuite suite) 
	{

	}
	@Override
	public void onTestFailure(ITestResult result) 
	{ 
		int InCount=result.getMethod().getCurrentInvocationCount();
		if(result.getMethod().getCurrentInvocationCount()>1)
		{
			GenericComponentImplementation.DPMethodName=(GenericComponentImplementation.currentMethodName+"_0"+InCount);
			ReportMethod.generateMethodHTMLReport(GenericComponentImplementation.DPMethodName,Reporter.getOutput(result));						
		}		 
		else
		{
			ReportMethod.generateMethodHTMLReport(GenericComponentImplementation.currentMethodName,Reporter.getOutput(result));
		}  	
	}
	public void onTestSuccess(ITestResult result) {
		try
		{
			int InCount=result.getMethod().getCurrentInvocationCount();
			InCount=InCount-1;
			if(result.getMethod().getCurrentInvocationCount()>1)
			{
				GenericComponentImplementation.DPMethodName=(GenericComponentImplementation.currentMethodName+"_0"+InCount);
				ReportMethod.generateMethodHTMLReport(GenericComponentImplementation.DPMethodName,Reporter.getOutput(result));						
			}		 
			else
			{
				ReportMethod.generateMethodHTMLReport(GenericComponentImplementation.currentMethodName,Reporter.getOutput(result));
			} 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void onTestSkipped(ITestResult result)
	{
		try
		{			
			System.out.println(Reporter.getOutput());
			Reporter.setCurrentTestResult(result);
			System.out.println(Reporter.getOutput().size());
			ReportMethod.generateMethodHTMLReport("BEFORE_AFTER"+TestCount,Reporter.getOutput());
			TestCount++;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	@Override
	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites,String outdir)
	{
		// TODO Auto-generated method stub
		ReportMethod.getOverAllDetails(suites);
		ReportMethod.generateReportSummary("Custom-Report",GenericComponentImplementation.outputDirectory,suites);    	 
	}
	public void onFinish(ISuite arg0) {
		// TODO Auto-generated method stub

	}



}
